export const ADD_ALERT = "ADD_ALERT";

export default {
    ADD_ALERT
};

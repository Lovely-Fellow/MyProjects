Inspiration for the pattern found in this directories files came from https://gist.github.com/sebmarkbage/ef0bf1f338a7182b6775

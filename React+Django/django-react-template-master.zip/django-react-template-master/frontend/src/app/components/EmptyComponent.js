import React from "react";


class EmptyComponent extends React.Component {
    render() {
        return null;
    }
}

export default EmptyComponent;

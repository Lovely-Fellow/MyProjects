<?php get_header(); ?>  

<div id="main-content">

	<?php if  ( is_tag() || is_category() || is_author() || is_archive() || is_home() || is_search() ): ?>
		<div class="blog-header">
			<div class="container"> 
				<div class=" et_pb_bg_layout_dark et_pb_text_align_center ">
					<?php if  ( is_home() ): 
						// Change text for Blog here
					?>
					<h1>Latest News</h1> 
					<?php elseif  ( is_tag() ): ?>
					<h1>Posts Tagged "<?php single_term_title();?>"</h1>
					<?php elseif  ( is_category() ): ?>
					<h1>Latest News - <?php single_cat_title();?></h1>
					<?php elseif  ( is_author() ): ?>
					<h1>Articles Posted by <?php the_author_meta( 'display_name' ); ?></h1>
					<?php elseif  ( is_archive() ): ?>
					<h1>Archive - <?php the_archive_title();?></h1> 
					<?php elseif  ( is_search() ): ?>
					<h1><?php printf( esc_html__( 'Search Results for: %s', stackstar ), '<span>' . get_search_query() . '</span>' ); ?></h1>
					<?php endif;?> 
				</div>
			</div>
			<div class="blog-divider"></div>
		</div>
	<?php endif;?>	
 
	<div <?php if  ( is_tag() || is_category() || is_author() || is_archive() || is_home() || is_search() ) echo 'class="container blog-below-header"';  else echo 'class="container"'; ?>>
		<div id="content-area" class="clearfix">
	
			<div id="left-area" >

				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); $post_format = et_pb_post_format(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'et_pb_post' ); ?>>
					
					<?php if ( ! in_array( $post_format, array( 'link', 'audio', 'quote' ) ) ) : ?>
					<div class="blog-post-header"> 
						<h2 class="entry-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>
						<?php et_divi_post_meta(); ?>	
					</div>
					<?php endif; ?>

					<?php
					$thumb     = '';
					$width     = (int) apply_filters( 'et_pb_index_blog_image_width', 1080 );
					$height    = (int) apply_filters( 'et_pb_index_blog_image_height', 675 );
					$classtext = 'et_pb_post_main_image';
					$titletext = get_the_title();
					$thumbnail = get_thumbnail( $width, $height, $classtext, $titletext, $titletext, false, 'Blogimage' );
					$thumb     = $thumbnail["thumb"];
					et_divi_post_format_content();
					if ( ! in_array( $post_format, array( 'link', 'audio', 'quote' ) ) ) {
					if ( 'video' === $post_format && false !== ( $first_video = et_get_first_video() ) ) :
					printf( '<div class="et_main_video_container">%1$s</div>', $first_video );
					elseif ( ! in_array( $post_format, array( 'gallery' ) ) && 'on' === et_get_option( 'divi_thumbnails_index', 'on' ) && '' !== $thumb ) : ?>
					<div class="image-container" >
						<a href="<?php the_permalink(); ?>">
							<?php print_thumbnail( $thumb, $thumbnail["use_timthumb"], $titletext, $width, $height ); ?>
							<span class="et_overlay"></span>
						</a>
					</div>
					<?php
					elseif ( 'gallery' === $post_format ) :
					et_pb_gallery_images();
					endif;
					} ?> 

					<div class="post-content">
						<p><?php truncate_post( 200 ); ?></p> 
					</div> 

				</article> <!-- .et_pb_post -->

				<?php
				endwhile;
				if ( function_exists( 'wp_pagenavi' ) ) {
					wp_pagenavi();
				} else {
					get_template_part( 'includes/navigation', 'index' );
				} else :
					get_template_part( 'includes/no-results', 'index' );
				endif;
				?>

			</div> <!-- #left-area -->

			<?php get_sidebar(); ?>

		</div> <!-- #content-area -->
	</div> <!-- .container -->    
</div> <!-- #main-content -->

<?php get_footer(); ?>
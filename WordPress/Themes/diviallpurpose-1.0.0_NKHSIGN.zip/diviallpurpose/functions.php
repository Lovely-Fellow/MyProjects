<?php


function theme_enqueue_styles() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style',
		get_stylesheet_directory_uri() . '/style.css',
		array( 'parent-style' )
	); 
	wp_enqueue_style( 'footer-style', get_stylesheet_directory_uri() . '/css/footer.css' );
	wp_enqueue_style( 'header-style', get_stylesheet_directory_uri() . '/css/header.css' );
	wp_enqueue_style( 'modules-style', get_stylesheet_directory_uri() . '/css/modules.css' ); 
	wp_enqueue_style( 'blog-style', get_stylesheet_directory_uri() . '/css/blog.css' ); 
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );

add_action('admin_enqueue_scripts', 'load_wp_admin_style_theme');

if (is_admin()) {

	require get_stylesheet_directory() . '/aspen-demo-content/admin-menu.php';

}


add_action('template_redirect', 'single_result');

function single_result()

{

    if (is_search()) {

        global $wp_query;

        if ($wp_query->post_count == 1) {

            wp_redirect(get_permalink($wp_query->posts['0']->ID));

        }

    }

}

function replace_howdy($wp_admin_bar)

{

    $my_account = $wp_admin_bar->get_node('my-account');

    $newtitle   = str_replace('Howdy,', 'Welcome,', $my_account->title);

    $wp_admin_bar->add_node(array(

        'id' => 'my-account',

        'title' => $newtitle

    ));

}

add_filter('admin_bar_menu', 'replace_howdy', 25);

function footer_inside_dashboard()

{

    echo 'Thank you for using <a href="http://divi.space/" target="_blank">Divi All Purpose Child Theme from Divi Space </a>';

}

add_filter('admin_footer_text', 'footer_inside_dashboard');

add_action('load-index.php', 'ags_welcome_panel');

function ags_welcome_panel()

{

    $user_id = get_current_user_id();

    if (1 != get_user_meta($user_id, 'ags_welcome_panel', true))

        update_user_meta($user_id, 'ags_welcome_panel', 1);

}

function allow_svgimg_types($mimes)

{

    $mimes['svg'] = 'image/svg+xml';

    return $mimes;

}

add_filter('upload_mimes', 'allow_svgimg_types');


function et_add_diviallpurpose_menu()

{

    add_menu_page('Divi All Purpose', 'Divi All Purpose', 'switch_themes', 'diviallpurpose-options', 'ags_diviallpurpose_index');

}
add_action('admin_menu', 'et_add_diviallpurpose_menu');

add_action('admin_menu', 'ags_diviallpurpose_admin');

function ags_diviallpurpose_admin()

{

    add_submenu_page('diviallpurpose-options', __('Theme Options', 'Divi'), __('Theme Options', 'Divi'), 'manage_options', 'diviallpurpose-options', 'ags_diviallpurpose_index');

}

function ags_diviallpurpose_featured_post_callback()

{

    echo '<a class="button-primary" href="admin.php?page=ags_demo_installer">Import Demo Data</a>';

}

function ags_diviallpurpose_index()

{

?>

    <div class="wrap">  

        <div id="icon-themes" class="icon32"></div>  

        <h2>AGS CT Demo Theme Options</h2>  

        <?php

    settings_errors();

?> 
        <?php

    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'front_page_options';

?>  
        <h2 class="nav-tab-wrapper">  

            <a href="?page=diviallpurpose-options&tab=front_page_options" class="nav-tab <?php

    echo $active_tab == 'front_page_options' ? 'nav-tab-active' : '';

?>">Demo Content</a>  

         <?php do_action('agsx_tabs', 'diviallpurpose-options', $active_tab); ?>

        </h2>  
        <form method="post" action="options.php">  

            <?php

    if ($active_tab == 'front_page_options') {

        settings_fields('ags_diviallpurpose_front_page_option');

        do_settings_sections('ags_diviallpurpose_front_page_option');

    } else {
		do_action('agsx_tab_content', $active_tab);
	}

?>
        </form> 
    </div> 

<?php

}

add_action('admin_init', 'ags_diviallpurpose_options');

function ags_diviallpurpose_options() {

	register_setting('ags_diviallpurpose_front_page_option', 'ags_diviallpurpose_front_page_option');
	
    add_settings_section('ags_diviallpurpose_front_page', 'Import Demo Data', 'ags_diviallpurpose_front_page_callback', 'ags_diviallpurpose_front_page_option');

    add_settings_field('featured_post', '', 'ags_diviallpurpose_featured_post_callback', 'ags_diviallpurpose_front_page_option', 'ags_diviallpurpose_front_page');

}

function ags_diviallpurpose_front_page_callback()

{

    echo '<div class="demo_content_options">

	

	<p>Use our built-in demo content tool. This will install the content and the design structure as shown in <a href="http://dap.aspengrovestudios.space/" target="_blank">this demo</a>. </p>

	

	<span>The items that will be imported are:</span> 

	

	<ul>

	<li>Demo text content</li>

	<li>Placeholder media files</li>

	<li>Navigation Menu</li>

	<li>Demo posts, pages and products</li>

	<li>Site widgets (<em>if applicable</em>)</li>

	</ul>

	<h3>Please note</h3>

	<ol>

	<li>

	No WordPress settings will be imported.</li>

	<li>No existing posts, pages, products, images, categories or any data will be modified or deleted.</li>

	<li>The importer will install only placeholder images showing their usage dimension. You can refer to our demo site and replace the placeholder with your own images.</li>

	</ol>

	</div>';

}

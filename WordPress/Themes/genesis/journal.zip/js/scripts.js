jQuery(function( $ ){
	
	// Show/hide sidebar on click
	$('.site-header .title-area .menu-button').click(function(){
		
		if( $(this).hasClass('dashicons-menu') ) {		
			
			$('.sidebar-primary').addClass('on');
			$(this).removeClass('dashicons-menu').addClass('dashicons-no-alt');

		} else {
			
			$('.sidebar-primary').removeClass('on');
			$(this).removeClass('dashicons-no-alt').addClass('dashicons-menu');
				
		}
		
		return false;
		
	});
	
	// Hide sidebar on click
	$('.sidebar-primary .dashicons-arrow-right-alt').click(function(){
		
		$('.sidebar-primary').removeClass('on');
		$('.site-header .title-area .menu-button').removeClass('dashicons-no-alt').addClass('dashicons-menu');
		
		return false;
		
	});
	
	// Hide sidebar on scroll
	$(window).scroll(function(){
		
		$('.sidebar-primary').removeClass('on');
		$('.site-header .title-area .menu-button').removeClass('dashicons-no-alt').addClass('dashicons-menu');
		
	});

});
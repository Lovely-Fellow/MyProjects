<?php
/**
 * This file adds the Home Page to the Journal Theme.
 *
 * @author Rafal Tomal
 * @package Journal
 * @subpackage Customizations
 */

//* Add homepage home-top
add_action( 'genesis_before_loop', 'journal_homepage_top', 0 );
function journal_homepage_top() {
	
	if ( is_active_sidebar( 'home-top' ) ) {
		
		genesis_widget_area( 'home-top', array(
	
			'before' => '<div id="home-top" class="home-top widget-area"><div class="wrap">',
			'after'  => '</div></div>',
			
		) );
		
	}
	
}

genesis();
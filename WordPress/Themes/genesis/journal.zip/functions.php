<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Journal Theme', 'journal' ) );
define( 'CHILD_THEME_URL', 'http://www.RafalTomal.com/' );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Enqueue scripts and fonts
add_action( 'wp_enqueue_scripts', 'journal_scripts' );
function journal_scripts() {
	
	// Dashicons
	wp_enqueue_style( 'dashicons' );
	
	// Google Fonts: 'Open Sans', 'Open Sans Condensed'
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,600,700|Open+Sans+Condensed:300,700', array(), CHILD_THEME_VERSION );
	
	// JS
	wp_enqueue_script( 'journal-scripts', get_bloginfo( 'stylesheet_directory' ) . '/js/scripts.js', array( 'jquery' ) );

}

//* Unregister site layouts
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-content' );

//* Unregister sidebars
unregister_sidebar( 'sidebar-alt' );
unregister_sidebar( 'header-right' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add a post featured image size
add_image_size( 'post-image', 1400, 500, TRUE );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Remove post meta
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Reposition post info
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
add_action( 'genesis_entry_header', 'genesis_post_info', 1 );

//* Customize the post info function
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter( $post_info ) {
	
	$post_info = '[post_date]';
	
	return $post_info;
}

//* Custom header
add_action( 'genesis_site_title', 'journal_header', 0 );
function journal_header(){
	
	$gravatar = get_avatar( get_option( 'admin_email' ), 100, '', get_bloginfo('name'));
	
	if( $gravatar )
		echo '<a href="' . get_bloginfo('url') . '">' . $gravatar . '</a>';
	
	
	$layout = genesis_site_layout();
	
	if( is_active_sidebar( 'sidebar' ) && $layout == 'content-sidebar' )
		echo '<a href="#" class="dashicons dashicons-menu menu-button">'. __( 'Menu', 'journal' ) .'</a>';
	
}

//* Remove the post image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );

//* Add separators
add_action( 'genesis_before_loop', 'journal_before_loop', 1 );
function journal_before_loop() {
	
	if( is_single() || is_page() ) {
		
		if( ! has_post_thumbnail() ) {
			
			echo '<div class="separator"></div>';
			
		}
		
	} else {
		
		echo '<div class="separator"></div>';
		
	}
	
}

//* Add featured image
add_action( 'genesis_before_entry', 'journal_featured_image', 0 );
function journal_featured_image() {
	
  	global $post;
  	
  	if( has_post_thumbnail() ) {
  	
		echo '<div class="featured-image">';
		
		if( ! is_single() )
			echo '<a href="' . get_permalink() . '">';
		
		the_post_thumbnail( 'post-image' );
		
		if( ! is_single() )
			echo '</a>';
		
		echo '</div>';
		
	}
	
}

//* Add a close button to the sidebar
add_action( 'genesis_sidebar', 'journal_close_button', 0 );
function journal_close_button() {
	
	echo '<a href="#" class="dashicons dashicons-arrow-right-alt"></a>';
	
}

//* Register widget areas
genesis_register_sidebar( array(
	'id'			=> 'home-top',
	'name'			=> __( 'Home Top', 'journal' ),
	'description'	=> __( 'This is the top section of the homepage.', 'journal' ),
) );
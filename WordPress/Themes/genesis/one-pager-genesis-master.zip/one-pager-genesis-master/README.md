=== One-Pager Genesis Child Theme ===

Theme demo: http://one-pager-genesis.wpdemos.co/

Blog Post: https://sridharkatakam.com/announcing-one-pager-one-page-parallax-website-child-theme-genesis/


=== Installation Instructions ===

1. Upload the one-pager theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the One-Pager for Genesis theme.
4. Visit https://sridharkatakam.com/announcing-one-pager-a-one-page-parallax-website-child-theme-for-genesis/ for details.


=== Theme Support ===

Post any issues or questions at https://github.com/srikat/one-pager-genesis/issues. No guaranteed support though.

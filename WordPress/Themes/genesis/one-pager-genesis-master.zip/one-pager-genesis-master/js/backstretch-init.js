jQuery(document).ready(function($) {

	$("#welcome").backstretch("http://websitesetuppro.com/demos/one-pager-genesis/wp-content/themes/one-pager/images/welcome-background.jpg");

	$("#portfolio").backstretch("http://websitesetuppro.com/demos/one-pager-genesis/wp-content/themes/one-pager/images/portfolio-background.jpg");

	$("#contact").backstretch("http://websitesetuppro.com/demos/one-pager-genesis/wp-content/themes/one-pager/images/contact-background.jpg");

	$("#about").backstretch("http://websitesetuppro.com/demos/one-pager-genesis/wp-content/themes/one-pager/images/about-background.jpg");

});
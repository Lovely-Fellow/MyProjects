Engage Theme

INSTALL
1. Upload the Engage theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Engage theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. 

WIDGET AREAS
After Entry - This is the after entry widget area.

SUPPORT
Please visit http://elioverbey.net for theme support.
jQuery(function( $ ){

	$('.market-archives .content .entry, .front-page .blog .entry, .category-index .featured-content .entry, .front-page-1 .featured-content .entry-header').matchHeight();

});
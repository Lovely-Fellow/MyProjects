BREAKPOINT THEME
http://themecraft.com/demo/breakpoint/

NOTE
After you download and unarchive the theme from GitHub, rename the breakpoint-master folder to breakpoint.

INSTALL
1. Upload the BreakPoint theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the BreakPoint theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.

SUPPORT
The BreakPoint theme is offered without support and is intended for users who are knowledgeable with WordPress and the Genesis Framework. 

=== Product Customizer Light ===
Contributors: k2servicecom
Tags: product customizer, customizer, visual designer
Donate link: http://k2-service.com/donation/
Requires at least: 4.4
Tested up to: 4.9.3
Requires PHP: 5.5
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Visual Product designer/customizer is a WordPress WooCommerce Plugin which is used to design or customize VISUALY any woocommerce products like Bikes, Headphones, Sunglasses, Watches, Controllers, T-shirts and even Pizzas – no limitations!

== Description ==
Do you want your customers to customize the product they want? We got you covered.
Visual Product designer/customizer is a WordPress WooCommerce Plugin which is used to design or customize VISUALY any woocommerce products like Bikes, Headphones, Sunglasses, Watches, Controllers, T-shirts and even Pizzas – no limitations!

- [Free] Simply build your own interface not only to compose a perfect product but also to have a preview of how final product will look like.

- [Free] Fully responsive and easy to use on any device without losing functionality.

- [Free] Preview the demo version of your customizer before launching it.

- [Free] Out of stock? Our plugin allows you to disable any custom product/option when needed.

- [Free] Visual Product designer/customizer is designed to integrate into wordpress/woocommerce natively.

- [Free] Set a different prices for products and options, choose from existing or create your own visual template, easily translate the plugin into any language and many more

- [Free] Export all customizers with images

- [Pro] Import all customizers with images & settings

- [Pro] Different templates for each customizer

- [Pro] Custom text & custom image loaded by customers on your product

- [Pro] Saving customizer with selected options and share it social networks

- [Pro] Print template for saved customizers

[Get Full Version](https://codecanyon.net/item/visual-product-designercustomizer-for-woocommerce/18935960)

== Installation ==
Easy Installation Steps


1. Upload directory `product-customizer-light` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add your first customizer

== Changelog ==
= 1.0.0 =
* Stable version of plugin.

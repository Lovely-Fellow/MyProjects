=== Export Themes ===
Contributors: milardovich
Tags: template,templates,clone templates,themes,copy themes,export themes, export, exporter
Requires at least: 4.0
Tested up to: 4.9.8
Stable tag: 2.1
Author: Sergio Milardovich

== Installation ==
Just paste this folder to the wp-content/plugins folder in your server and then activate it from the backend. You will found a new item in the "Appearence" menu called "Export".
Besides, you can also use the Wordpress repository from the dashboard to install it.

== Description ==
With this plugin you'll be able to export your themes in a .zip file and then install with that .zip file the same theme in other servers using the "upload" feature of wordpress.

== Usage ==
After installing the plugin, you need to go to the "Export" subsection in the "Appearence" menu. Just select the theme you want and then click in the "Export" button. You will get a .zip file to download. Once you have the .zip file in your computer, you can install the theme going to Appearence/Themes/Install Themes/Upload in your wordpress administration pannel, and then select your .zip file and click on "Install now".

== Changelog ==
[29-11-2011] 1.5
* Permisson problems fixed.
* Warnings added.
* Directory structure changed.

[04-09-2014] 2.0
* Security bug fixed
* Old zip files are automatically deleted
* Better session management
* 100% WP 4.0 Compatible

[22-09-2018] 2.1
* Warning fixed
* Language functions added

== Screenshots ==
1. "Export" option in the apparience menu.
2. Wp-clone-template running.
3. Just another screenshot.

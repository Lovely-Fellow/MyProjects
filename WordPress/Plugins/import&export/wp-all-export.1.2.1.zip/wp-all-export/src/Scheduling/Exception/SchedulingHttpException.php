<?php

namespace Wpae\Scheduling\Exception;


class SchedulingHttpException extends \Exception
{

}
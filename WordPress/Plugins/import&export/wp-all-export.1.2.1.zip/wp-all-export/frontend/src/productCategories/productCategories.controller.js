GoogleMerchants.controller('productCategoriesController', ['$scope', '$log', 'BACKEND', function($scope, $log, BACKEND){

}]);
GoogleMerchants.controller('uniqueIdentifiersController', ['$scope', function($scope){

}]);
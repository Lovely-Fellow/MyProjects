=== Flockler social wall ===
Contributors: flockler
Tags: social media aggregator, social media feeds, Facebook feed, Instagram feed, Twitter feed, YouTube
Requires at least: 4.0
Tested up to: 4.9.8
Stable tag: trunk
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Flockler brings all your social content into one social wall.

== Description ==

Flockler plugin enables you to display all your social content, including what your fans say about you, as a social wall. Collate social content manually or set up rules to publish content automatically based on hashtags or usernames.

In addition to social content, you can create your own editorial content (blog posts, product news etc.). All the content created and curated on Flockler is stored to WordPress Posts and shown on your website just like any other WordPress-powered content, therefore making it SEO-friendly.

Plugin automatically creates a layout optimised for mobile, tablet and desktop, but as the content is stored to WordPress, there's an option to create a fully customised look & feel together with your technical team.

Features:

- Create blog posts. Blog posts are displayed as any other content you create on WordPress.
- Curate content from social channels such as Twitter, Instagram, Facebook, YouTube and more. All the content is stored to WordPress Posts and is SEO-friendly.
- Automatically pull in content from social channels based on usernames or hashtags. Display automatically or store for moderation. New content updated every 5 minutes.
- Create multiple streams of content based on topics, content type etc.
- Automatically optimised layout for mobile, tablet and desktop. As all the content is stored to WordPress, there's an option create a custom look & feel together with your technical team.
- Multiple admin accounts.
- Support via live-chat, email and phone.
- SLA and enterprise level hosting. Flockler is trusted by companies such as Intel, Penguin Books and Expedia.

Here's how the admins can curate content manually [https://www.youtube.com/watch?v=WWGX65YpqoQ](https://www.youtube.com/watch?v=WWGX65YpqoQ)

Here's how the admins can set up rules to pull in content automatically from social channels [https://www.youtube.com/watch?v=Y9Jo6UKP4tk](https://www.youtube.com/watch?v=Y9Jo6UKP4tk)

30-day Free Trial. Our plans start from 49 € / month. See more details [https://flockler.com/plans-and-pricing](https://flockler.com/plans-and-pricing)

Learn more about Flockler [https://flockler.com](https://flockler.com)


== Installation ==

1. In your WordPress admin panel, go to Plugins > New Plugin, search for "Flockler Social Wall" and click "Install now"
2. Alternatively, download the plugin and upload the contents of `flockler-social-wall.zip` to your plugins directory, which usually is `/wp-content/plugins/`
3. Activate the plugin
4. Go to Settings > Flockler
5. Type in a name for your webhook (e.g. "Default") and click "Add"
6. Copy the Webhook URL to the clipboard
7. Open Flockler in a new window/tab: [https://flockler.com/newsroom](https://flockler.com/newsroom) (if you don't have a Flockler site yet, you can create one at [https://flockler.com/free-trial](https://flockler.com/free-trial))
8. *On Flockler:* Go to Settings > Webhooks and click "Create new webhook"
9. *On Flockler:* Paste the webhook URL from WordPress to the URL field and continue to step 2.
9. Copy the secret from step 2 to the clipboard, go back to WordPress, and click "Edit" on the webhook ([screenshot](http://developers.flockler.com/assets/images/wp-plugin/webhook-edit-button-6a3e0881.png))
9. Paste the secret into the "Secret" field and click "Save" ([screenshot](http://developers.flockler.com/assets/images/wp-plugin/webhook-edit-modal-9fb1a24d.png))
9. *On Flockler:* Continue on from the secret step and select if you'd like to publish only the content collated on Flockler in the future or publish all the content already collated on Flockler (and all future content) to your WordPress site.
9. Done!

#### Need help?

Please visit [Flockler Help center](https://help.flockler.com/) for help in using Flockler.

If you can't find your answer, click the blue & white speech bubble in the bottom right corner to start a chat with us, or contact team@flockler.com.


== Frequently Asked Questions ==

= Do you offer support? =

Yes, we offer support. We have a knowledge base at [https://help.flockler.com/](https://help.flockler.com/) with a live chat. Live chat is also available in the Flockler web app. You can also reach us via email `team@flockler.com`

= I can't see the Flockler posts in WordPress? =

1. Make sure you've sent some articles from Flockler; simply creating a webhook does not send old content => posts created before creating webhook have to be sent manually
2. Check Posts > Flockler on WordPress admin and see if there any posts there
  - => No posts? None have been sent from Flockler
  - => Posts say "Scheduled"? The server clock is probably misaligned. Check the UTC time in WP from Settings > General > Timezone. It should match the UTC time (can be off by some minutes)
3. Make sure you meet the technical requirements and MySQL is version 5.5+
4. Still nothing? Contact team@flockler.com, we are happy to help!

= libssl/openssl something error when trying to register webhooks in WP? =

Your WordPress server might not have libssl, or it's not configured properly. Please install/configure libssl. Our WordPress plugin uses SSL for encryption so that your WordPress site stays safe.

= Duplicate content? =

Most common cause is other plugins. Check your plugins. W3TC (W3 Total Cache), WP Super Cache and other plugins are known to cause this.

If you have W3TC (W3 Total Cache) plugin installed: open W3TC's Database cache settings > Reject query words > add word "lock" on its own line like here: [W3TC query word settings](https://www.dropbox.com/s/eyl4c03ccnfp726/Screenshot%202016-05-06%2012.01.39.png?dl=0)

If you have some other plugin, especially cache plugins, check if they have an option to disable database cache or query cache or to disable caching certain queries. **All queries containing the word "lock" should not be cached.**

Also: Check your MySQL version (v5.5+ required), and your MySQL configuration. DB locking should be enabled.

*Technical details:* We use MySQL's GET_LOCK and RELEASE_LOCK commands to lock the database when we are adding or updating posts so that we can prevent duplicates. Some plugins break these commands, such as W3TC which incorrectly caches these commands.

= How do I change MySQL tables & columns to use utf8mb4? =

If your database tables are not using utf8mb4 you might be missing posts or have problems with posts with emojis.

WordPress actually has a feature that can upgrade your database to use utf8mb4:

1. Add the snippet from [https://gist.github.com/flori...0ba7046200fd0b7519918e0](https://gist.github.com/flori...0ba7046200fd0b7519918e0) into e.g. your theme's functions.php
2. Open your site with "?update-utf8bm4=1" e.g. [http://www.example.com/?update-utf8bm4=1](http://www.example.com/?update-utf8bm4=1)
3. Confirm that the columns in wp_posts and wp_postmeta were changed with `SHOW FULL COLUMNS FROM wp_posts;` and `SHOW FULL COLUMNS FROM wp_postmeta;`
4. Remove the snippet from functions.php so it can't be triggered anymore

Note: We have tested this only up to WordPress 4.9.2

== Screenshots ==

1. Collate social media from: Twitter, Instagram, Facebook, YouTube and more...
2. Set up rules to gather content automatically
3. Audience analytics
4. Flockler social wall is responsive

== Changelog ==

= 2.5.4 =
* fixed video aspect ratio for Facebook wall items
* show Instagram video covers using Instagram's media URL
* force HTTPS in oEmbed codes

= 2.5.3 =
* fixed cover images not working when images are hosted on e.g. S3 (= cover images are now added as actual post attachments)

= 2.5.2 =
* added link to Settings on Plugins page
* fixed some PHP notices

= 2.5.1 =
* publicly released on WordPress.org

var flj = jQuery.noConflict();

flj(document).ready(function () {
    var $ = flj;
    if ($('body').is('.settings_page_flockler-webhooks')) {
        var initModal = function(modalName) {
            var tmpl = _.template($('#webhook-' + modalName + '-modal-dialog').text());
            var $el = $('<div></div>').appendTo('body').dialog({
                modal: true,
                draggable: false,
                autoOpen: false,
                resizable: false,
                open: function() {
                    $('#flockler_webhook_' + modalName + '_cancel').click(function() {
                        $el.dialog("close");
                    });
                }
            });

            $('.flockler_webhook_' + modalName + '_button').click(function() {
                var line = $(this).parents('tr').eq(0);
                $el.html(tmpl({
                    id: line.data('id'),
                    name: line.data('name'),
                    secret: line.data('secret')
                })).dialog('open');
            });
        };

        initModal('update');
        initModal('delete');
    }
});

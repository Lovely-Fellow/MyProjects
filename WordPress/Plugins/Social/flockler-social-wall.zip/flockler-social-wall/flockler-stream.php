<?php
/*
  @wordpress-plugin
  Plugin Name: Flockler social wall
  Plugin URI: https://developers.flockler.com/plugins/wordpress/
  Description: Flockler brings all your social content into one social wall
  Version: 2.5.4
  Author: Flockler
  Author URI: https://flockler.com
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('FLOCKLER_PLUGIN_NAME', 'Flockler');
define('FLOCKLER_PLUGIN_TEXT_DOMAIN', 'flockler-wordpress');
define('FLOCKLER_STREAM_PATH', plugin_dir_path(__FILE__));
define('FLOCKLER_STREAM_URL', plugin_dir_url(__FILE__));
define('FLOCKLER_STREAM_SHORTCODE', 'flockler-stream');
define('FLOCKLER_STREAM_DEFAULT_COUNT', 8);
define('FLOCKLER_STREAM_DEFAULT_WIDTH', '346');
define('FLOCKLER_DB_LOCK_NAME', 'wp_flockler_plugin_lock');
define('FLOCKLER_POST_TYPE_NAME', 'flockler_post');
define('FLOCKLER_POST_SLUG', 'content');

require('includes/parser.inc.php');

class Flockler_Stream
{
    /* --------------------------------------------*
     * Attributes
     * -------------------------------------------- */

    /** Refers to a single instance of this class. */
    private static $instance = null;

    /* --------------------------------------------*
     * Constructor
     * -------------------------------------------- */

    private $standard_messages;

    /**
     * Creates or returns an instance of this class.
     *
     * @return  Flockler_Stream A single instance of this class.
     */
    public static function get_instance() {

        if (null == self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;
    }
// end get_instance;

    /**
     * Initializes the plugin by setting localization, filters, and administration functions.
     */
    private function __construct() {
        // Register actions to perform upon (de)activation of the plugin
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));

        add_action('plugins_loaded', array($this, 'shortcode_initialize'));
        add_action('plugins_loaded', array($this, 'locales_initialize'));

        add_action('wp_enqueue_scripts', array($this, 'js_load_site'), 999);
        add_action('admin_enqueue_scripts', array($this, 'js_load_admin'), 999);

        add_action('wp_enqueue_scripts', array($this, 'css_load_site'));
        add_action('admin_enqueue_scripts', array($this, 'css_load_admin'));

        add_action('admin_footer', array($this, 'templates_load_admin'));

        // Register a settings page for configuring the webhooks
        add_action('admin_menu', array($this, 'admin_options_install'));

        add_action('init', array($this, 'register_post_types'));
        add_action('admin_init', array($this, 'post_type_meta_fields_register'));

        add_action('init', array($this, 'webhooks_handler'));

        add_action('admin_notices', array($this, 'admin_notices'));

        add_action('wp_ajax_flockler_get_posts', array($this, 'ajax_get_posts'));
        add_action('wp_ajax_nopriv_flockler_get_posts', array($this, 'ajax_get_posts'));

        add_filter('pre_get_posts', array($this, 'get_posts_by_default'));

        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));

        $this->standard_messages = array();
    }
// end constructor

    /* --------------------------------------------*
     * Functions
     * -------------------------------------------- */

    function locales_initialize() {
        load_plugin_textdomain(FLOCKLER_PLUGIN_TEXT_DOMAIN, false, dirname( plugin_basename( __FILE__ ) ) . '/languages');
    }

    function shortcode_initialize() {
        add_shortcode(FLOCKLER_STREAM_SHORTCODE, array($this, 'shortcode_handler'));
    }

    function shortcode_handler($atts, $content = "") {
        $a = shortcode_atts(array(
            'count'   => FLOCKLER_STREAM_DEFAULT_COUNT,
            'webhook' => '',
            'site'    => '',
            'section' => '',
            'width'   => FLOCKLER_STREAM_DEFAULT_WIDTH,
        ), $atts, FLOCKLER_STREAM_SHORTCODE);

        $count   = !empty($a['count'])   ? (int) $a['count']    : FLOCKLER_STREAM_DEFAULT_COUNT;
        $webhook = !empty($a['webhook']) ?       $a['webhook']  : '';
        $site    = !empty($a['site'])    ?       $a['site']     : null;
        $section = !empty($a['section']) ?       $a['section']  : null;
        $width   = !empty($a['width'])   ?       $a['width']    : FLOCKLER_STREAM_DEFAULT_WIDTH;

        if (empty($webhook) && empty($site) && empty($section)) {
            $initErrorText = __('Flockler wall could not be initialized; parameters are missing.', FLOCKLER_PLUGIN_TEXT_DOMAIN);
            return '<div>'.$initErrorText.'</div>';
        }

        $widthAttr = empty($width)  ? '' : 'data-flockler-item-width="' . $width  . '"';

        $post_data = $this->get_posts_db(false, $webhook, $site, $section, $count, $width);
        $posts = implode('', $post_data['articles']);
        $loadMoreButtonText = __('Load more', FLOCKLER_PLUGIN_TEXT_DOMAIN);

        if (count($post_data['articles']) >= $count) {
            $loadMoreButton =
<<< EOS
              <div class="flockler-wall__load-more">
                  <button id="loadmore" class="flockler-wall__load-more-btn">{$loadMoreButtonText}</button>
              </div>
EOS;
        }

        return
<<< EOS
          <div class="flockler-wall-widget-container">
              <div class="flockler-wall"
                    data-flockler-item-count="{$count}"
                    data-flockler-webhook-id="{$webhook}"
                    data-flockler-site-id="{$site}"
                    data-flockler-section-id="{$section}"
                    data-initial-max-post-id="{$post_data['pagination']['max_id']}"
                    {$widthAttr}>
                  <div class="flockler-wall__items">
                    {$posts}
                  </div>
                  {$loadMoreButton}
              </div>
          </div>
EOS;
    }

    /**
     * Load javascript
     */
    function js_load_site() {
        wp_register_script('imagesloaded', FLOCKLER_STREAM_URL . 'assets/js/vendor/imagesloaded.pkgd.min.js');
        wp_register_script('masonry', FLOCKLER_STREAM_URL . 'assets/js/vendor/masonry.pkgd.min.js');
        wp_register_script('jquery-oembed', FLOCKLER_STREAM_URL . 'assets/js/vendor/jquery-oembed.min.js');
        wp_enqueue_script('flockler-stream', FLOCKLER_STREAM_URL . 'assets/js/min/flockler-stream.min.js', array('jquery', 'jquery-oembed', 'imagesloaded', 'masonry'), '', true);

        wp_localize_script('flockler-stream', 'ajaxData', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }

    function js_load_admin() {
        if (!wp_script_is('underscore')) {
            // Not present in a vanilla installation of 3.2 at least
            wp_register_script('underscore', FLOCKLER_STREAM_URL . 'assets/js/vendor/underscore-min.js');
        }

        wp_enqueue_script('underscore');
        wp_enqueue_script('jquery-ui-dialog');
        wp_enqueue_script('flockler-stream-admin', FLOCKLER_STREAM_URL . 'assets/js/flockler-stream-admin.js', array('jquery', 'jquery-ui-dialog', 'underscore'));
    }

    /**
     * Load CSS
     */
    function css_load_site() {
        if (!is_admin())
            wp_enqueue_style('flockler-stream', FLOCKLER_STREAM_URL . 'assets/css/styles.css');
    }

    function css_load_admin() {
        wp_enqueue_style('flockler-stream', FLOCKLER_STREAM_URL . 'assets/css/styles-admin.css');
        wp_enqueue_style('jquery-ui-base', FLOCKLER_STREAM_URL . 'assets/css/jquery-ui.structure.min.css');
        wp_enqueue_style('jquery-ui-theme', FLOCKLER_STREAM_URL . 'assets/css/jquery-ui.theme.min.css');
    }

    function templates_load_admin() {
      echo '<script type="text/html" id="webhook-update-modal-dialog">'
        . file_get_contents(FLOCKLER_STREAM_PATH . 'includes/webhook-edit.tpl.ejs')
        . '</script>'
        . '<script type="text/html" id="webhook-delete-modal-dialog">'
        . file_get_contents(FLOCKLER_STREAM_PATH . 'includes/webhook-del.tpl.ejs')
        . '</script>';
    }

    function plugin_action_links($links) {
        $settings_link = '<a href="options-general.php?page=flockler-webhooks">' . __( 'Settings' ) . '</a>';
        array_push($links, $settings_link);
        return $links;
    }

    function admin_notices() {
        foreach ($this->standard_messages as $msg) {
            ?>
                <div class="notice notice-<?php echo $msg[1] ?>">
                    <p><?php echo $msg[0] ?></p>
                </div>
            <?php
        }
    }

    function admin_options_install() {
        $settings_page = add_options_page(
            FLOCKLER_PLUGIN_NAME,
            'Flockler',
            'manage_options',
            'flockler-webhooks',
             array($this, 'webhooks_settings_render')
        );

        // Handle the POST requests here
        add_action('load-' . $settings_page, array($this, 'webhooks_settings_handle_post'));
        add_action('load-' . $settings_page, array($this, 'check_requirements'));
    }

    function check_requirements() {
        // Display a warning about a breaking option combination in PHP settings if relevant
        // The deprecation warning about $HTTP_RAW_POST_DATA since PHP 5.6.0 is very unfortunate in that it is
        // triggered even when correctly using php://input instead of the deprecated global - PHP receiving POST data
        // other than from a HTML form will regardless always print the error unless the said setting is set to -1.
        // In production systems, display_errors should of course never be active, but you can never know...
        // https://bugs.php.net/bug.php?id=66763
        if (version_compare(phpversion(), '5.6.0', '>=')
            && version_compare(phpversion(), '7.0.0', '<')
            && ini_get('display_errors')
            && ini_get('always_populate_raw_post_data') !== '-1')
        {
            $this->display_standard_message(<<<MSGEND
<strong>Incompatible configuration detected!</strong> To prevent certain warnings being forcefully included in JSON responses to Webhooks,
please set the value of the setting <em>always_populate_raw_post_data</em> to -1 or <em>display_errors</em> to 0 in your
PHP configuration file.
MSGEND
                , 'warning is-dismissable');
        }

        // Display warning if tables are not using utf8mb4

        if ($this->has_non_utf8mb4_column()) {
            $this->display_standard_message(<<<MSGEND
<strong>Incompatible database detected!</strong> Posts with emojis and other 4-byte characters might not show up on your site.
See our <a href="https://developers.flockler.com/plugins/wordpress/#troubleshooting" target="_blank">Troubleshooting</a> section for tips on how to fix this.
MSGEND
                , 'warning is-dismissable');
        }
    }

    public function register_post_types() {
        register_post_type(FLOCKLER_POST_TYPE_NAME, array(
            'label' => 'Flockler',
            'description' => 'Automatically generated post obtained from a Flockler site',
            'public' => true,
            'hierarchical' => false,
            'show_ui' => true,
            'show_in_menu' => 'edit.php',
            'rewrite' => array('slug' => FLOCKLER_POST_SLUG),
            'query_var' => FLOCKLER_POST_SLUG,
            'supports' => array('author')
        ));

        add_filter('the_content', array($this, 'post_type_transform_content'));
        add_filter('the_title', array($this, 'post_type_transform_title'));
        add_filter('previous_post_link', array($this, 'post_type_prevent_cross_nav'));
        add_filter('next_post_link', array($this, 'post_type_prevent_cross_nav'));
    }

    function post_type_prevent_cross_nav($val) {
        global $post;

        if ($post->post_type === FLOCKLER_POST_TYPE_NAME) {
            return false;
        }

        return $val;
    }

    // Renders body on single post page
    function post_type_transform_content($content) {
        global $post;

        if ($post->post_type === FLOCKLER_POST_TYPE_NAME) {
            $data = get_post_meta($post->ID, 'flockler_post_full_data', true);

            $settings = $this->webhooks_get_settings();

            $data['local_id'] = $post->ID;
            $data['local_permalink'] = get_permalink($post->ID);

            $content = '<div class="flockler-post-single-container">' . $this->render_post($data, $settings) . '</div>';
        }
        return $content;
    }

    // Renders title on single post page
    function post_type_transform_title($content, $id = null) {
        global $post;

        if (in_the_loop() && is_single() && $post->post_type === FLOCKLER_POST_TYPE_NAME) {
            $data = get_post_meta($post->ID, 'flockler_post_full_data', true);

            // if (array_search($data['type'], array('video', 'article')) === false) {
            //     return false;
            // }
        }
        return $content;
    }

    function post_type_meta_fields_register() {
        // These fields are just for convenience. They'll display the Flockler post ID and the friendly name of the
        // assigned webhook, but they cannot be edited from the administrative UI.
        add_meta_box(
            'flockler_post_information_fields',
            'Internal data',
            array($this, 'post_type_meta_fields_render'),
            FLOCKLER_POST_TYPE_NAME,
            'side',
            'low'
        );
        add_meta_box(
            'flockler_post_main_content_fields',
            'Post details',
            array($this, 'post_type_main_data_render'),
            FLOCKLER_POST_TYPE_NAME,
            'normal',
            'high'
        );
    }

    function post_type_meta_fields_render($post) {
        ?>
        <div>
            <label for="flockler_post_internal_id">
                Flockler post ID
            </label>
        </div>
        <input type="text" disabled="disabled" id="flockler_post_internal_id" value="<?php
        echo esc_attr(get_post_meta($post->ID, 'flockler_post_internal_id', true));
        ?>">

        <div>
            <label for="flockler_post_site_id">
                Flockler site ID
            </label>
        </div>
        <input type="text" disabled="disabled" id="flockler_post_site_id" value="<?php
        echo esc_attr(get_post_meta($post->ID, 'flockler_post_site_id', true));
        ?>">
        <div>
            <label for="flockler_post_section_id">
                Flockler section ID
            </label>
        </div>
        <input type="text" disabled="disabled" id="flockler_post_section_id" value="<?php
        echo esc_attr(get_post_meta($post->ID, 'flockler_post_section_id', true));
        ?>">
        <div>
            <label for="flockler_post_webhook_name">
                Assigned Webhook
            </label>
        </div>
        <input type="text" disabled="disabled" id="flockler_post_webhook_name" value="<?php
        $hook_id = get_post_meta($post->ID, 'flockler_post_webhook_id', true);

        $settings = $this->webhooks_get_hook_list();
        echo $settings[$hook_id]['name'];
        ?>">

        <?php
    }

    function post_type_main_data_render($post) {
        $data = get_post_meta($post->ID, 'flockler_post_full_data', true);
        ?>
        <table class="form-table">
            <tr>
                <th>Title</th>
                <td><?php the_title(); ?></td>
            </tr>
            <tr>
                <th>Type</th>
                <td><?php echo ucfirst($data['type']); ?></td>
            </tr>
            <tr>
                <th>Text body</th>
                <td><?php echo wp_kses_post( apply_filters('the_content', get_the_content()) ); ?></td>
            </tr>
            <?php if (!empty($data['tags'])) : ?><tr>
                <th>Tags</th>
                <td><?php echo wp_kses_data( join(', ', $data['tags']) ); ?></td>
            </tr><?php endif; ?>
            <?php if (!empty($data['cover_url'])) : ?><tr>
                <th>Cover image</th>
                <td><img alt="" class="flockler-post-settings-cover-preview" src="<?php echo $data['cover_url']; ?>"></td>
            </tr><?php endif; ?>
            <?php
                if (sizeof($data['attachments']) > 0) {
                    ?>
                    <tr>
                        <th colspan="2"><h3>Attached content</h3></th>
                    </tr>
                    <?php
                    switch ($data['type']) {
                        case 'tweet': ?>
                            <tr>
                                <th>User</th>
                                <td><?php echo $data['attachments']['tweet']['name'] . ' (@'
                                             . $data['attachments']['tweet']['screen_name'] . ')'; ?></td>
                            </tr>
                            <tr>
                                <th>Tweet text</th>
                                <td><?php echo $data['attachments']['tweet']['text']; ?></td>
                            </tr>
                            <?php if ($data['attachments']['tweet']['media_url'] !== null) { ?>
                                <tr>
                                    <th>Tweet media</th>
                                    <td><img alt="" class="flockler-post-settings-cover-preview" src="<?php echo $data['attachments']['tweet']['media_url']; ?>"></td>
                                </tr>
                            <?php }
                        break;
                        case 'facebook_post': ?>
                            <tr>
                                <th>User</th>
                                <td><?php echo $data['attachments']['facebook_post']['from_name']; ?></td>
                            </tr>
                            <tr>
                                <th>Post content</th>
                                <td><?php echo $data['attachments']['facebook_post']['message']; ?></td>
                            </tr>
                            <?php if ($data['attachments']['facebook_post']['post_type'] !== null) { ?>
                                <tr>
                                    <th>Additional media</th>
                                    <td><?php echo $data['attachments']['facebook_post']['post_type']; ?></td>
                                </tr>
                            <?php }
                            break;
                        case 'instagram': ?>
                            <tr>
                                <th>User</th>
                                <td><?php echo $data['attachments']['instagram_item']['username']; ?></td>
                            </tr>
                            <tr>
                                <th>Caption</th>
                                <td><?php echo $data['attachments']['instagram_item']['caption']; ?></td>
                            </tr>
                            <?php if ($data['attachments']['instagram_item']['media_type'] !== null) { ?>
                                <tr>
                                    <th>Type of media</th>
                                    <td><?php echo $data['attachments']['instagram_item']['media_type']; ?></td>
                                </tr>
                            <?php }
                        break;
                        case 'video': ?>
                            <tr>
                                <th>Service</th>
                                <td><?php echo $data['attachments']['video']['service']; ?></td>
                            </tr>
                            <tr>
                                <th>User</th>
                                <td><?php echo $data['attachments']['video']['username']; ?></td>
                            </tr>
                        <?php break;
                    }
                }
            ?>
        </table>
        <?php
    }

    function webhooks_handler() {
        if (isset($_GET['flockler-hook'])) {
            $key = mb_strtolower($_GET['flockler-hook']);
            if (preg_match("/^[0-9a-f]{32}$/",$key) === false) {
                $this->webhooks_send_json(400, array(
                    'message' => 'invalid Webhook ID'
                ));
            }

            $hooks = $this->webhooks_get_hook_list();
            if (!isset($hooks[$key])) {
                $this->webhooks_send_json(400, array(
                    'message' => 'invalid Webhook ID'
                ));
            }

            if (!isset($_SERVER['HTTP_X_FLOCKLER_ENV'])) {
                $this->webhooks_send_json(400, array(
                    'message' => 'environment header is missing'
                ));
            }

            if (!isset($_SERVER['HTTP_X_FLOCKLER_ACTION'])) {
                $this->webhooks_send_json(400, array(
                    'message' => 'action header is missing'
                ));
            }

            if (!isset($_SERVER['HTTP_X_FLOCKLER_SIGNATURE'])) {
                $this->webhooks_send_json(400, array(
                    'message' => 'signature is missing'
                ));
            }

            // Read raw POST data
            $payload = file_get_contents('php://input');

            // Check signature
            $webhook_secret = $this->webhooks_get_hook_secret($hooks[$key]);
            $webhook_url = $this->webhooks_get_hook_url($hooks[$key]);
            if (!$this->webhooks_request_signed($webhook_secret, $webhook_url, $payload)) {
                $this->webhooks_send_json(400, array(
                    'message' => 'invalid signature'
                ));
            }

            // Read JSON
            $data = json_decode($payload, true);

            if (is_null($data)) {
                $this->webhooks_send_json(400, array(
                    'message' => 'body not valid JSON'
                ));
            }

            // Action can be read from either headers or the payload itself, so we'll use the latter
            if (!isset($data['action'])) {
                $this->webhooks_send_json(400, array(
                    'message' => 'action is missing'
                ));
            }
            if (!isset($data['article'])) {
                $this->webhooks_send_json(400, array(
                    'message' => 'article is missing'
                ));
            }

            $lock_status = $this->webhooks_acquire_db_lock();
            if ($lock_status !== "1") {
                // Lock timed out or could not be obtained because of some kind of error
                $this->webhooks_send_json(500, array(
                    'message' => 'could not acquire database lock'
                ));
            }

            $id = $data['article']['id'];
            $posts = get_posts(array(
                'post_type' => FLOCKLER_POST_TYPE_NAME,
                'post_status' => 'future,publish',
                'meta_query' => array(
                    array(
                        'key' => 'flockler_post_internal_id',
                        'value' => $id
                    )
                )
            ));

            if (sizeof($posts) > 0 && $data['action'] == 'publish') {
                // The Flockler post ID already exists in our database, but it was pushed from the main service again.
                // Assume it's safe to update it instead.
                $data['action'] = 'update';
            }

            if (sizeof($posts) == 0 && $data['action'] == 'update') {
                // The Flockler post ID doesn't exist in our database, but it was updated.
                // It was probably created before the hook was added, so add it instead.
                $data['action'] = 'publish';
            }

            $post_date = strtotime($data['article']['published_at']);

            switch($data['action']) {
                case 'publish':
                    $post_id = wp_insert_post(array(
                        'post_content' => $data['article']['body'],
                        'post_title' => $data['article']['title'],
                        'post_name' => $data['article']['article_url'],
                        'post_status' => 'publish',
                        'post_type' => FLOCKLER_POST_TYPE_NAME,
                        'post_author' => 0,
                        'post_date' => date('Y-m-d H:i:s', $post_date)
                    ));
                    $data['article']['cover_url'] = $this->webhooks_fetch_thumbnail($data['article']['cover_url'], $post_id);
                    update_post_meta($post_id, 'flockler_post_internal_id', $data['article']['id']);
                    update_post_meta($post_id, 'flockler_post_site_id', $data['article']['site_id']);
                    update_post_meta($post_id, 'flockler_post_section_id', $data['article']['section_id']);
                    update_post_meta($post_id, 'flockler_post_webhook_id', $key);
                    update_post_meta($post_id, 'flockler_post_full_data', $data['article']);

                    $this->webhooks_release_db_lock();
                    $this->webhooks_send_json(200, array(
                        'wp_post_id' => $post_id,
                        'message' => 'added'
                    ));
                    break;
                case 'unpublish':
                    if (sizeof($posts) == 0) {
                        // This is "OK" and not "Bad Request" because it might just as well be that the specific
                        // article was created before the hook was added
                        $this->webhooks_release_db_lock();
                        $this->webhooks_send_json(404, array(
                            'message' => 'post not found'
                        ));
                    }

                    $this->webhooks_cleanup_thumbnail($data['article']['id']);
                    wp_delete_post($posts[0]->ID, true);

                    $this->webhooks_release_db_lock();
                    $this->webhooks_send_json(200, array(
                        'wp_post_id' => $posts[0]->ID,
                        'message' => 'deleted'
                    ));
                    break;
                case 'update':
                    wp_update_post(array(
                        'ID' => $posts[0]->ID,
                        'post_content' => $data['article']['body'],
                        'post_title' => $data['article']['title'],
                        'post_name' => $data['article']['article_url'],
                        'post_status' => 'publish',
                        'post_type' => FLOCKLER_POST_TYPE_NAME,
                        'post_author' => 0,
                        'post_date' => date('Y-m-d H:i:s', $post_date)
                    ));
                    $data['article']['cover_url'] = $this->webhooks_fetch_thumbnail($data['article']['cover_url'], $posts[0]->ID);
                    update_post_meta($posts[0]->ID, 'flockler_post_internal_id', $data['article']['id']);
                    update_post_meta($posts[0]->ID, 'flockler_post_site_id', $data['article']['site_id']);
                    update_post_meta($posts[0]->ID, 'flockler_post_section_id', $data['article']['section_id']);
                    update_post_meta($posts[0]->ID, 'flockler_post_webhook_id', $key);
                    update_post_meta($posts[0]->ID, 'flockler_post_full_data', $data['article']);

                    $this->webhooks_release_db_lock();
                    $this->webhooks_send_json(200, array(
                        'wp_post_id' => $posts[0]->ID,
                        'message' => 'updated'
                    ));
                    break;
                default:
                    $this->webhooks_release_db_lock();
                    $this->webhooks_send_json(400, array(
                        'message' => 'unknown action specified'
                    ));

            }

        }
    }

    function webhooks_acquire_db_lock() {
        global $wpdb;

        return $wpdb->get_var($wpdb->prepare("SELECT GET_LOCK(%s, 10)", FLOCKLER_DB_LOCK_NAME));
    }

    function webhooks_release_db_lock() {
        global $wpdb;

        return $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)", FLOCKLER_DB_LOCK_NAME));
    }

    function webhooks_cleanup_thumbnail($id) {
        $upload_dir = wp_upload_dir();

        if (file_exists($upload_dir['basedir'] . '/flockler_thumbs/thumb_' . $id . '.jpg')) {
            unlink($upload_dir['basedir'] . '/flockler_thumbs/thumb_' . $id . '.jpg');
        }
    }

    function webhooks_fetch_thumbnail($cover, $post_id) {
        if (empty($cover)) {
            return $cover;
        }

        // Switch the URL on the fly to the thumbnail from the API, if the image comes from Flockler servers
        // Based on the method used for the JS template
        $thumb_pattern = "//flockler.com/thumbs/$1/$2_s400x0_q70_noupscale.$3";
        $resized_cover = preg_replace('#//flockler\.com/thumbs/(\d+)/([^/\.]+)_s\d+x\d+\w*\.(\w+)$#', $thumb_pattern, $cover);
        $resized_cover = preg_replace('#//flockler\.com/files/(\d+)/([^/\.]+)\.(\w+)$#', $thumb_pattern, $cover);

        // Need to require these files
        if ( !function_exists('media_sideload_image') ) {
            require_once(ABSPATH . 'wp-includes/pluggable.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
        }

        $media = media_sideload_image($resized_cover, $post_id, null, 'src');

        if (is_wp_error($media)) {
            return $resized_cover;
        } else {
            return $media;
        }
    }

    function webhooks_send_json($code, $data) {
        // Add own implementation, WP's own JSON functions were only added in 3.5.0 and they don't use HTTP codes
        // properly anyway

        $data['status'] = $code;
        $plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), false);
        $data['plugin_version'] = $plugin_data['Version'];

        header('Content-Type: application/json; charset=utf-8', true, $code);
        echo json_encode($data);
        exit;
    }

    function webhooks_send_jsonp($data, $cb) {
        header('Content-Type: application/javascript; charset=utf-8', true);
        echo $cb . '(' . json_encode($data) . ')';
        exit;
    }

    function webhooks_settings_handle_post() {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'add':
                    $this->webhooks_add();
                    break;
                case 'remove':
                    $this->webhooks_remove();
                    break;
                case 'update':
                    $this->webhooks_update();
                    break;
                case 'set_settings':
                    $this->webhooks_update_settings();
                    break;
            }
        }
    }

    function webhooks_settings_render() {
        $hooks = $this->webhooks_get_hook_list();
        $settings = $this->webhooks_get_settings();

        include(FLOCKLER_STREAM_PATH . 'includes/webhooks_settings.inc.php');
    }

    function webhooks_get_hook_name(&$item) {
        return $item['name'];
    }

    function webhooks_get_hook_url(&$item) {
        return get_site_url() . "/?flockler-hook=" . $item['id'];
    }

    function webhooks_get_hook_secret(&$item) {
        return $item['secret'];
    }

    function webhooks_request_signed($secret, $url, $payload) {
        $http_verb = $_SERVER['REQUEST_METHOD'];
        $action = $_SERVER['HTTP_X_FLOCKLER_ACTION'];
        $env = $_SERVER['HTTP_X_FLOCKLER_ENV'];
        $ext_signature = $_SERVER['HTTP_X_FLOCKLER_SIGNATURE'];

        $str_to_sign = mb_strtolower(implode('|', array(
          $http_verb,
          $action,
          $env,
          $url,
          $payload
        )));

        $signature = base64_encode(hash_hmac('sha256', $str_to_sign, $secret, true));

        return $ext_signature == $signature;
    }

    function webhooks_add() {
        if (!current_user_can('manage_options')) {
            $this->display_standard_message('Access denied.', 'error');
            return;
        }

        $hooks = $this->webhooks_get_hook_list();

        // Verify that an unique name was given for the webhook
        $used_names = array_map(array($this, "webhooks_get_hook_name"), $hooks);
        $name = '';
        if (isset($_POST['webhook_name'])) {
            $name = $this->webhooks_escape_name($_POST['webhook_name']);
            if (array_search($name, $used_names) !== false) {
                $this->display_standard_message('There is already a webhook with that name!', 'error');
                return;
            }

            if (strlen($name) === 0) {
                $this->display_standard_message('A name must be provided!', 'error');
                return;
            }
        } else {
            $this->display_standard_message('A name must be provided!', 'error');
            return;
        }

        // Generate a random key with OpenSSL if available, otherwise by a less sophisticated method.
        // IDs here do not need to be cryptographically secure, but it is definitely beneficial for them
        // to not be sequential so that manual probing becomes more difficult.
        if (extension_loaded('openssl')) {
            $id = bin2hex(openssl_random_pseudo_bytes(16));
        } else {
            $id = '';
            $range = "0123456789abcdef";
            for ($i = 0; $i < 32; $i++) {
                $id .= $range[mt_rand(0, 15)];
            }
        }

        // Users most likely never generate more than a couple IDs each, so collisions with IDs of this length
        // should be nonexistent. If it so happens that such a rare coincidence still occurs (odds are n/(2^128) for
        // n existing keys), let the user just try submitting it again.
        if (isset($hooks['id'])) {
            $this->display_standard_message('A collision occurred while generating a new key, please try again.', 'error');
            return;
        }

        $hooks[$id] = array(
            'id' => $id,
            'name' => $name,
            'secret' => ''
        );

        $this->webhooks_set_hook_list($hooks);

        $this->display_standard_message('Webhook <em>' . $name . '</em> created.', 'updated');
    }

    function webhooks_remove() {
        if (!current_user_can('manage_options')) {
            $this->display_standard_message('Access denied.', 'error');
            return;
        }

        $hooks = $this->webhooks_get_hook_list();

        if (isset($_POST['id'])) {
            if (!isset($hooks[$_POST['id']])) {
                $this->display_standard_message('Cannot remove a webhook by that ID.', 'error');
                return;
            }
        } else {
            $this->display_standard_message('Cannot remove a webhook by that ID.', 'error');
            return;
        }

        $name = $hooks[$_POST['id']]['name'];
        unset($hooks[$_POST['id']]);

        // Remove all the posts that were assigned to this webhook
        $posts = get_posts(array(
            'post_type' => FLOCKLER_POST_TYPE_NAME,
            'meta_query' => array(
                array(
                    'key' => 'flockler_post_webhook_id',
                    'value' => $_POST['id']
                )
            )
        ));
        foreach($posts as $post) {
            $this->webhooks_cleanup_thumbnail(get_post_meta($post->ID, 'flockler_post_internal_id', true));
            wp_delete_post($post->ID, true);
        }

        $this->webhooks_set_hook_list($hooks);

        $this->display_standard_message('Webhook <em>' . $name . '</em> removed.', 'updated');
    }

    function webhooks_update() {
        if (!current_user_can('manage_options')) {
            $this->display_standard_message('Access denied.', 'error');
            return;
        }

        $hooks = $this->webhooks_get_hook_list();

        if (isset($_POST['id'])) {
            if (!isset($hooks[$_POST['id']])) {
                $this->display_standard_message('The specified webhook was not found.', 'error');
                return;
            }
        } else {
            $this->display_standard_message('The specified webhook was not found.', 'error');
            return;
        }

        $used_names = array_map(array($this, "webhooks_get_hook_name"), $hooks);
        $name = '';
        if (isset($_POST['webhook_name'])) {
            $name = $this->webhooks_escape_name($_POST['webhook_name']);
            if ((array_search($name, $used_names) !== false) && ($name != $hooks[$_POST['id']]['name'])) {
                $this->display_standard_message('There is already a webhook with that name!', 'error');
                return;
            }

            if (strlen($name) === 0) {
                $this->display_standard_message('A name must be provided!', 'error');
                return;
            }
        } else {
            $this->display_standard_message('A name must be provided!', 'error');
            return;
        }

        $secret = $_POST['webhook_secret'];

        $hooks[$_POST['id']]['name'] = $name;
        $hooks[$_POST['id']]['secret'] = $secret;
        $this->webhooks_set_hook_list($hooks);

        $this->display_standard_message('Webhook <em>' . $name . '</em> updated.', 'updated');
    }

    function webhooks_update_settings() {
        if (!current_user_can('manage_options')) {
            $this->display_standard_message('Access denied.', 'error');
            return;
        }

        $settings = $this->webhooks_get_settings();
        $boolean_fields = array(
            'in_blog',
            'twitter_share_button',
            'facebook_share_button',
            'linkedin_share_button',
            'wall_item_timestamps'
        );

        foreach ($boolean_fields as $field) {
            $settings[$field] = (bool) ($_POST[$field] == '1' || $_POST[$field] == 'on' || $_POST[$field] == 'true');
        }

        if (isset($_POST['image_width'])) {
            $settings['image_width'] = (int)$_POST['image_width'];

            if ($settings['image_width'] == 0) {
                $settings['image_width'] = '';
            } else if ($settings['image_width'] < 50) {
                $settings['image_width'] = 50;

                $this->display_standard_message('Minimum image width is 50.', 'error');
                $this->webhooks_set_settings($settings);

                return;
            } else if ($settings['image_width'] > 3000) {
                $settings['image_width'] = 3000;

                $this->display_standard_message('Maximum image width is 3000.', 'error');
                $this->webhooks_set_settings($settings);

                return;
            }
        }

        $this->webhooks_set_settings($settings);
        $this->display_standard_message('Settings updated.', 'updated');
    }

    function webhooks_escape_name($name) {
        // Implement a variant of sanitize_text_field, which is not present before 2.9.0
        $filtered = preg_replace("/[\\\\&<>\"]/", "", $name);

        if (function_exists('wp_check_invalid_utf8')) {
            $filtered = wp_check_invalid_utf8($filtered);
        }

        while (preg_match('/%[a-f0-9]{2}/i', $filtered, $match)) {
            $filtered = str_replace($match[0], '', $filtered);
        }

        $filtered = trim(preg_replace('/ +/', ' ', $filtered));

        return $filtered;
    }

    function webhooks_get_hook_list() {
        $hooks = get_option('flockler_webhooks');
        if (empty($hooks)) {
            $hooks = array();
        }
        return $hooks;
    }

    function webhooks_set_hook_list($settings) {
        return update_option('flockler_webhooks', $settings);
    }

    function webhooks_get_settings() {
        return get_option('flockler_webhooks_settings');
    }

    function webhooks_set_settings($settings) {
        return update_option('flockler_webhooks_settings', $settings);
    }

    function display_standard_message($message, $class) {
        if ($class == 'updated') {
            $class = 'success';
        }

        array_push($this->standard_messages, array($message, $class));
    }

    function get_posts_db($is_ajax, $hook_id, $site_id, $section_id, $count, $width_attr, $offset = 0, $max_id = null) {
        $meta_query = array('relation' => 'AND');

        if (!empty($hook_id)) {
            array_push($meta_query, array(
                'key' => 'flockler_post_webhook_id',
                'value' => $hook_id
            ));
        }

        if (!empty($site_id)) {
            array_push($meta_query, array(
                'key' => 'flockler_post_site_id',
                'value' => $site_id
            ));
        }

        if (!empty($section_id)) {
            array_push($meta_query, array(
                'key' => 'flockler_post_section_id',
                'value' => $section_id
            ));
        }

        $query = array(
            'post_type' => FLOCKLER_POST_TYPE_NAME,
            'meta_query' => $meta_query,
            'posts_per_page' => $count,
            'orderby' => 'date',
            'fields' => 'ids'
        );

        if (is_numeric($offset) && $offset > 0) {
            $query['offset'] = $offset;
        } else {
            $offset = 0;
        }

        $posts = get_posts($query);
        $post_data = array();

        $last_flockler_id = 0;
        $last_wp_id = 0;

        if (sizeof($posts) > 0) {
            if (sizeof($post_data) > 0) {
                $last_wp_id = $post_data[sizeof($post_data) - 1]['ID'];
            }

            foreach ($posts as $item) {
                $post_custom_data = get_post_custom($item);
                $post_custom_data = maybe_unserialize($post_custom_data['flockler_post_full_data'][0]);

                if (is_array($post_custom_data)) {
                    $post_custom_data['local_id'] = $item;
                    $post_custom_data['local_permalink'] = get_permalink($item);
                }

                // Capture the Flockler ID of the last post in the array to use in the "next posts" pagination URL
                if ($last_wp_id === $item['ID']) {
                    $last_flockler_id = $post_custom_data['id'];
                }

                $width = null;
                if (preg_match('/^\d+$/', $width_attr)) {
                    $width = $width_attr . 'px';
                } else if (preg_match('/^\d+(\.\d+)?%$/', $width_attr)) {
                    $width = $width_attr;
                } else if ($width_attr === '') {
                    $width = '346px';
                }

                $settings = $this->webhooks_get_settings();

                $post_data[] = $this->render_wall_item($post_custom_data, array(
                    'facebook_share_button' => $settings['facebook_share_button'],
                    'linkedin_share_button' => $settings['linkedin_share_button'],
                    'twitter_share_button' => $settings['twitter_share_button'],
                    'itemWidth' =>  $width,
                    'wall_item_timestamps' => $settings['wall_item_timestamps']
                ));
            }
        }

        if (!empty($_GET['count']) && sizeof($post_data) == $_GET['count']) {
            $params = array(
                'max_id' => $last_flockler_id,
                'hook_id' => $_GET['hook_id'],
                'site_id' => $_GET['site_id'],
                'section_id' => $_GET['section_id'],
                'offset' => $offset + sizeof($posts),
                'count' => $_GET['count'],
                'width' => $_GET['width'],
                'action' => $_GET['action']
            );

            $older = $_SERVER['SCRIPT_NAME'] . '?' . http_build_query($params);
        } else {
            $older = null;
        }

        $reply = array(
            'meta' => array(
                'count' => sizeof($posts)
            ),
            'articles' => $post_data,
            'pagination' => array(
                'offset' => $offset,
                'older'  => $older,
                'max_id' => $last_flockler_id
            )
        );
        if ($is_ajax) {
            $this->webhooks_send_jsonp($reply, $_GET['callback']);
        } else {
            return $reply;
        }
    }

    function ajax_get_posts() {
        if (empty($_GET['hook_id']) && empty($_GET['site_id']) && empty($_GET['section_id'])) {
            $this->webhooks_send_json(400, array(
                'message' => 'unknown action specified'
            ));
        }

        $this->get_posts_db(
            true,
            isset($_GET['hook_id'])     ? $_GET['hook_id']      : NULL,
            isset($_GET['site_id'])     ? $_GET['site_id']      : NULL,
            isset($_GET['section_id'])  ? $_GET['section_id']   : NULL,
            isset($_GET['count'])       ? $_GET['count']        : NULL,
            isset($_GET['width'])       ? $_GET['width']        : NULL,
            isset($_GET['offset'])      ? $_GET['offset']       : NULL,
            isset($_GET['max_id'])      ? $_GET['max_id']       : NULL
        );
    }

    function get_posts_by_default($query) {
        if (is_home() && $query->is_main_query()) {
            $settings = $this->webhooks_get_settings();
            if (isset($settings) && !$settings['in_blog']) {
                return $query;
            }

            $current = $query->get('post_type');
            if (!is_array($current)) {
                $current = array('post');
            }
            $query->set('post_type', array_merge($current, array(FLOCKLER_POST_TYPE_NAME)));
        }

        return $query;
    }

    function has_attachments($item) {
        return count($item['attachments']) > 0;
    }

    private function render_wall_item($item, $settings) {
        if (!is_array($item) || !is_array($settings)) {
            return '';
        }

        ob_start();
        require('includes/stream.inc.php');
        $content = ob_get_contents();
        ob_end_clean();

        return $content;
    }

    private function render_post($item, $settings) {
        if (!is_array($item) || !is_array($settings)) {
            return '';
        }

        $image_width = $settings['image_width'];

        if ($image_width && is_numeric($image_width)) {
            $item['body'] = preg_replace('/(src=\"https?:\/\/flockler\.com\/thumbs\/\d+\/.+_s)(600)/', '${1}'.$image_width, $item['body']);
        }

        ob_start();
        require('includes/article.inc.php');
        $content = ob_get_contents();
        ob_end_clean();

        return $content;
    }

    private function migrate_flockler_post_relation_ids() {
        // Add site_id and section_id post metas for those missing them
        $query = array(
            'post_type' => FLOCKLER_POST_TYPE_NAME,
            'meta_query' => array(
                array(
                    'key' => 'flockler_post_site_id',
                    'compare' => 'NOT EXISTS'
                )
            ),
            'fields' => 'ids'
        );

        $posts = get_posts($query);

        foreach ($posts as $post) {
            $post_custom = get_post_custom($post);
            $post_raw_data = maybe_unserialize($post_custom['flockler_post_full_data'][0]);

            if (is_array($post_raw_data)) {
                $site_id = $post_raw_data['site_id'];
                $section_id = $post_raw_data['section_id'];
                update_post_meta($post, 'flockler_post_site_id', $site_id);
                update_post_meta($post, 'flockler_post_section_id', $section_id);
            }
        }
    }

    private function initialize_settings() {
        $defaults = array(
            'in_blog' => true,
            'twitter_share_button' => true,
            'facebook_share_button' => true,
            'linkedin_share_button' => false,
            'wall_item_timestamps' => false,
            'image_width' => 600
        );

        // Initialize settings if they don't exist
        $was_initialized = add_option('flockler_webhooks_settings', $defaults);

        if (!$was_initialized) {
            // Make sure default settings are set
            $settings = $this->webhooks_get_settings();
            $settings = array_merge($defaults, $settings);
            $this->webhooks_set_settings($settings);
        }
    }

    public function activate_plugin() {
        add_option('flockler_webhooks', array());

        $this->initialize_settings();
        $this->migrate_flockler_post_relation_ids();
        $this->register_post_types();
        flush_rewrite_rules(false);
    }

    public function deactivate_plugin() {
        flush_rewrite_rules(false);
    }

    private function get_parser($text, $summary = false) {
        return new Flockler_Stream_Post_Parser($text, $summary);
    }

    // Checks if any of the core tables are not on utf8mb4 which is critical for our content (social content often has emojis etc.)
    function has_non_utf8mb4_column() {
        global $wpdb;

        if ( is_multisite() ) {
            $tables = $wpdb->tables( 'blog' );
        } else {
            $tables = $wpdb->tables( 'all' );
            $global_tables = $wpdb->tables( 'global' );
            $tables        = array_diff_assoc( $tables, $global_tables );
        }

        foreach ( $tables as $table ) {
            $results = $wpdb->get_results( "SHOW FULL COLUMNS FROM `$table`" );

            if ( ! $results ) {
                return false;
            }

            foreach ( $results as $column ) {
                if ( $column->Collation ) {
                    list( $charset ) = explode( '_', $column->Collation );
                    $charset = strtolower( $charset );
                    if ( 'utf8mb4' !== $charset ) {
                        return true;
                    }
                }
            }
        }
    }
}

// end class

Flockler_Stream::get_instance();

<div class="flockler-wall-item" <?php echo $itemWidth ?>>
    <div class="flockler-wall-item__content">
        <?php if($item['cover_url']) : ?>
            <div class="flockler-wall-item__media">
                <img src="<?php echo $this->get_parser($item['cover_url'])->useThumbnail()->done() ?>" class="flockler-wall-item__media__img" />
            </div>
        <?php endif; ?>

        <div class="flockler-wall-item__title flockler-wall-item__padding">
            <a href="<?php echo $item['local_permalink'] ?>" class="flockler-wall-item__title-link"><?php echo $item['title'] ?></a>
        </div>

        <?php if($item['body'] && $item['body'] != "") : ?>
            <div class="flockler-wall-item__body">
                <?php echo $this->get_parser($item['body'], $item['summary'])->parseURL()->makeSummary($item['local_permalink'])->done(); ?>
            </div>
        <?php endif; ?>

        <?php if ($item['local_permalink']) { ?>
            <div class="flockler-wall-item__footer">
                <?php if ($settings['wall_item_timestamps']) : ?>
                    <div class="flockler-wall-item__timestamps">
                        <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/timestamp.inc.php'); ?>
                    </div>
                <?php endif; ?>
                <div class="flockler-wall-item__share">
                    <div class="flockler-wall-item__share_actions">
                        <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/share_actions.inc.php'); ?>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

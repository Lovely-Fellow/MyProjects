<time class="flockler-wall-item__published-at" itemprop="datePublished"
    datetime="<?php echo date('c', strtotime($item['published_at'])); ?>" pubdate>
    <span class="flockler-wall-item__published-at__date"><?php echo date_i18n(get_option('date_format'), strtotime($item['published_at'])); ?></span>
    <span class="flockler-wall-item__published-at__time"><?php echo date_i18n(get_option('time_format'), strtotime($item['published_at'])); ?></span>
</time>

<a href="https://twitter.com/intent/tweet?in_reply_to=<?php echo $item['attachments']['tweet']['tweet_id_str'] ?>" title="<?php _e('Reply', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?>"
   class="flockler-wall-item__share-action flockler-wall-item__share-action--reply" target="_blank">
  <i class="flockler-icon-reply"></i>
  <span><?php echo _e('Reply', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?></span>
</a>
<a href="https://twitter.com/intent/retweet?tweet_id=<?php echo $item['attachments']['tweet']['tweet_id_str'] ?>" title="<?php _e('Retweet', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?>"
   class="flockler-wall-item__share-action flockler-wall-item__share-action--retweet" target="_blank">
  <i class="flockler-icon-retweet"></i>
  <span><?php echo _e('Retweet', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?></span>
</a>
<a href="https://twitter.com/intent/like?tweet_id=<?php echo $item['attachments']['tweet']['tweet_id_str'] ?>" title="<?php _e('Like', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?>"
   class="flockler-wall-item__share-action flockler-wall-item__share-action--like" target="_blank">
  <i class="flockler-icon-heart"></i>
  <span><?php _e('Like', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?></span>
</a>

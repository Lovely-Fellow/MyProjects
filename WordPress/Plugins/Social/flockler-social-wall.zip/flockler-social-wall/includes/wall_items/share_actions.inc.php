<?php
    $url = '';
    $text = $item['title'];
    $summary = $item['summary'];

    if ($item['type'] == 'facebook') {
        $url = 'https://www.facebook.com/'  . $item['attachments']['facebook_post']['post_id_str'];
    } elseif ($item['type'] == 'instagram') {
        $url = $item['attachments']['instagram_item']['link'];
    } elseif ($item['type'] == 'video') {
        $url = !empty($item['attachments']['video']['original_url']) ? $item['attachments']['video']['original_url'] : $item['local_permalink'];
    } else {
        $url = $item['local_permalink'];
    }

    $twittershare = 'https://twitter.com/intent/tweet?url=' . urlencode($url) . '&text=' . urlencode($text);
    $fbshare = 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode($url) . '&t=' . urlencode($text);
    $linkedinshare = 'https://www.linkedin.com/shareArticle?mini=true&url=' . urlencode($url) . '&title=' . urlencode($text) . '&summary=' . urlencode($summary);
?>
<?php if ($settings['twitter_share_button']) : ?>
<a href="<?php echo $twittershare ?>" title="<?php _e('Share on Twitter', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?>"
    class="flockler-wall-item__share-action flockler-wall-item__share-action--twitter" target="_blank">
    <i class="flockler-icon-twitter"></i>
    <span><?php _e('Share on Twitter', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?></span>
</a>
<?php endif; ?>
<?php if ($settings['facebook_share_button']) : ?>
<a href="<?php echo $fbshare ?>" title="<?php _e('Share on Facebook', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?>"
    class="flockler-wall-item__share-action flockler-wall-item__share-action--facebook" target="_blank">
    <i class="flockler-icon-facebook"></i>
    <span><?php _e('Share on Facebook', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?></span>
</a>
<?php endif; ?>
<?php if ($settings['linkedin_share_button']) : ?>
<a href="<?php echo $linkedinshare ?>" title="<?php _e('Share on LinkedIn', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?>"
    class="flockler-wall-item__share-action flockler-wall-item__share-action--linkedin" target="_blank">
    <i class="flockler-icon-linkedin"></i>
    <span><?php _e('Share on LinkedIn', FLOCKLER_PLUGIN_TEXT_DOMAIN) ?></span>
</a>
<?php endif; ?>

<div class="flockler-wall-item flockler-wall-item--instagram" <?php echo $itemWidth; ?>>
    <div class="flockler-wall-item__content">
        <?php $instagram_link = preg_replace('#instagram\.com/[^/]+/p/#', 'instagram.com/p/', $item['attachments']['instagram_item']['link']); ?>
        <?php if (!$item['attachments']['instagram_item']['video_standard_resolution']) { ?>
            <div class="flockler-wall-item__media">
                <a target="_blank" href="<?php echo $item['attachments']['instagram_item']['link'] ?>">
                    <img src="<?php echo $instagram_link ?>media"
                         alt="<?php printf(__('Instagram photo by %s', FLOCKLER_PLUGIN_TEXT_DOMAIN), '@'.$item['attachments']['instagram_item']['username']) ?>"
                         class="flockler-wall-item__media__img"/>
                </a>
            </div>
        <?php } ?>
        <?php if ($item['attachments']['instagram_item']['video_standard_resolution']) { ?>
            <div class="flockler-wall-item__video">
                <img class="instagram-video flockler-wall-item__video__img" src="<?php echo $instagram_link ?>media/?size=l" />
                <button class="flockler-wall-item__media__video-icon html5-embed" data-videosrc="<?php echo $item['attachments']['instagram_item']['video_standard_resolution'] ?>">
                    <div class="flockler-wall-item__media__video-icon__arrow"></div>
                </button>
            </div>
        <?php } ?>
        <div class="flockler-wall-item__body">
            <?php if($item['attachments']['instagram_item']['caption']) { ?>
                <?php echo $this->get_parser($item['attachments']['instagram_item']['caption'])->parseIUsername()->parseIHashtag()->done() ?>
            <?php } ?>
        </div>

        <div class="flockler-wall-item__footer">
            <div class="flockler-wall-item__profile">
                <div class="flockler-wall-item__profile__avatar">
                    <img src="<?php echo $item['attachments']['instagram_item']['profile_picture'] ?>" alt="" class="flockler-wall-item__profile__avatar-img">
                </div>
                <div class="flockler-wall-item__profile__body">
                    <a href="http://instagram.com/<?php echo $item['attachments']['instagram_item']['username'] ?>" class="flockler-wall-item__profile__name"  target="_blank"><?php echo $item['attachments']['instagram_item']['username'] ?></a>
                    <a href="<?php echo $item['attachments']['instagram_item']['link'] ?>" class="flockler-wall-item__profile__detail" target="_blank">
                        <?php if ($settings['wall_item_timestamps']) : ?>
                            <i class="flockler-icon-instagram"></i>
                            <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/timestamp.inc.php'); ?>
                        <?php else : ?>
                            Instagram
                        <?php endif; ?>
                    </a>
                </div>
            </div>
            <div class="flockler-wall-item__share">
                <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/share_actions.inc.php'); ?>
            </div>
        </div>
    </div>
</div>

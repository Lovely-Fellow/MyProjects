<div class="flockler-wall-item flockler-wall-item--link" <?php echo $itemWidth ?>>
    <div class="flockler-wall-item__content">
        <?php if($item['body'] && $item['body'] != "") : ?>
            <div class="flockler-wall-item__body">
                <?php echo $this->get_parser($item['body'], $item['summary'])->parseURL()->makeSummary($item['source_url'], true)->done(); ?>
            </div>
        <?php endif; ?>

        <?php
          $_link_preview = array(
            'url' => $item['attachments']['link']['original_url'],
            'cover_url' => $item['attachments']['link']['cover_url'],
            'title' => $item['attachments']['link']['title'],
            'description' => $item['attachments']['link']['description']
          );
        ?>
        <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/link_preview.inc.php'); ?>

        <div class="flockler-wall-item__footer">
            <?php if ($settings['wall_item_timestamps']) : ?>
                <div class="flockler-wall-item__timestamps">
                    <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/timestamp.inc.php'); ?>
                </div>
            <?php endif; ?>
            <div class="flockler-wall-item__share">
                <div class="flockler-wall-item__share-actions">
                    <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/share_actions.inc.php'); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="flockler-wall-item flockler-wall-item--pinterest" <?php echo $itemWidth; ?>>
    <div class="flockler-wall-item__content">
        <div class="flockler-wall-item__media">
            <a target="_blank" href="<?php echo $item['attachments']['pinterest_item']['link'] ?>">
                <img src="<?php echo $item['attachments']['pinterest_item']['images']['large'] ?>"
                      alt="<?php printf(__('Pin by %s', FLOCKLER_PLUGIN_TEXT_DOMAIN), '@'.$item['attachments']['pinterest_item']['username']) ?>"
                      class="flockler-wall-item__media__img"/>
            </a>
        </div>
        <div class="flockler-wall-item__body">
            <?php if (!empty($item['attachments']['pinterest_item']['description'])) : ?>
                <?php echo $item['attachments']['pinterest_item']['description']; ?>
            <?php elseif (!empty($item['attachments']['pinterest_item']['title'])) : ?>
                <?php echo $item['attachments']['pinterest_item']['title']; ?>
            <?php elseif (!empty($item['summary'])) : ?>
                <?php echo $item['body']; ?>
            <?php else : ?>
                <?php echo $item['body']; ?>
            <?php endif; ?>
        </div>

        <div class="flockler-wall-item__footer">
            <div class="flockler-wall-item__profile">
                <?php if (!empty($item['attachments']['pinterest_item']['profile_picture'])) : ?>
                    <div class="flockler-wall-item__profile__avatar">
                        <img src="<?php echo $item['attachments']['pinterest_item']['profile_picture'] ?>" alt="" class="flockler-wall-item__profile__avatar-img">
                    </div>
                <?php endif; ?>
                <div class="flockler-wall-item__profile__body">
                    <a href="http://pinterest.com/<?php echo $item['attachments']['pinterest_item']['username'] ?>" class="flockler-wall-item__profile__name"  target="_blank"><?php echo $item['attachments']['pinterest_item']['username'] ?></a>
                    <a href="<?php echo $item['attachments']['pinterest_item']['link'] ?>" class="flockler-wall-item__profile__detail" target="_blank">
                        <?php if ($settings['wall_item_timestamps']) : ?>
                            <i class="flockler-icon-pinterest"></i>
                            <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/timestamp.inc.php'); ?>
                        <?php else : ?>
                            Pinterest
                        <?php endif; ?>
                    </a>
                </div>
            </div>
            <div class="flockler-wall-item__share">
                <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/share_actions.inc.php'); ?>
            </div>
        </div>
    </div>
</div>

<div class="flockler-wall-item flockler-wall-item--facebook" <?php echo $itemWidth ?>>
    <div class="flockler-wall-item__content">

        <?php if($item['attachments']['facebook_post']['picture'] && $item['attachments']['facebook_post']['post_type'] == 'photo') { ?>
            <div class="flockler-wall-item__media">
                <img src="<?php echo $item['attachments']['facebook_post']['picture'] ?>" alt="<?php printf(__('Facebook photo by %s', FLOCKLER_PLUGIN_TEXT_DOMAIN), $item['attachments']['facebook_post']['from_name']) ?>" class="flockler-wall-item__media__img">
            </div>
        <?php } ?>

        <?php if($item['attachments']['facebook_post']['picture'] && $item['attachments']['facebook_post']['post_type'] == 'video') { ?>
            <div class="flockler-wall-item__video">
                <img class="facebook-video flockler-wall-item__video__img" src="<?php echo $item['attachments']['facebook_post']['picture'] ?>" alt="">
                <button class="flockler-wall-item__media__video-icon embed" data-videosrc="<?php echo $item['attachments']['facebook_post']['link'] ?>">
                    <div class="flockler-wall-item__media__video-icon__arrow"></div>
                </button>
            </div>
        <?php } ?>

        <div class="flockler-wall-item__body">
            <?php if($item['attachments']['facebook_post']['message'] && $item['attachments']['facebook_post']['message'] != "") { ?>
                <?php echo $this->get_parser($item['attachments']['facebook_post']['message'])->parseNewLines()->parseFBHashtag()->parseURL()->done() ?>
            <?php } ?>
        </div>

        <?php if($item['attachments']['facebook_post']['post_type'] == 'link' ) { ?>
          <?php
            $_link_preview = array(
              'url' => $item['attachments']['facebook_post']['link'],
              'cover_url' => $item['attachments']['facebook_post']['picture'],
              'title' => $item['attachments']['facebook_post']['link_name'],
              'description' => $item['attachments']['facebook_post']['link_description'],
              'meta' => $item['attachments']['facebook_post']['link_caption']
            );
          ?>
          <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/link_preview.inc.php'); ?>
        <?php } ?>

        <div class="flockler-wall-item__footer">
            <div class="flockler-wall-item__profile">
                <div class="flockler-wall-item__profile__avatar">
                    <img src="https://graph.facebook.com/<?php echo $item['attachments']['facebook_post']['from_id_str'] ?>/picture?type=square" alt="" class="flockler-wall-item__profile__avatar-img">
                </div>
                <div class="flockler-wall-item__profile__body">
                    <a href="https://www.facebook.com/<?php echo $item['attachments']['facebook_post']['from_id_str'] ?>" class="flockler-wall-item__profile__name" target="_blank"><?php echo $item['attachments']['facebook_post']['from_name'] ?></a>
                    <a href="https://www.facebook.com/<?php echo $item['attachments']['facebook_post']['post_id_str'] ?>" class="flockler-wall-item__profile__detail" target="_blank">
                        <?php if ($settings['wall_item_timestamps']) : ?>
                            <i class="flockler-icon-facebook"></i>
                            <?php require(FLOCKLER_STREAM_PATH.'includes/wall_items/timestamp.inc.php'); ?>
                        <?php else : ?>
                            Facebook
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="flockler-article__fb-attachment">
  <div class="flockler-article__fb-attachment__profile">
    <figure class="flockler-article__fb-attachment__profile__picture">
      <a href="https://facebook.com/<?php echo $item['attachments']['facebook_post']['from_id_str'] ?>" target="_blank">
        <img src="https://graph.facebook.com/<?php echo $item['attachments']['facebook_post']['from_id_str'] ?>/picture?type=square" alt="" title="" class="flockler-article__fb-attachment__profile__picture__img">
      </a>
    </figure>
    <div class="flockler-article__fb-attachment__profile__body">
      <a href="https://facebook.com/<?php echo $item['attachments']['facebook_post']['from_id_str'] ?>" target="_blank" class="flockler-article__fb-attachment__profile__name"><?php echo $item['attachments']['facebook_post']['from_name'] ?></a>
      <span class="flockler-article__fb-attachment__profile__context">
        <?php if (!empty($item['attachments']['facebook_post']['commenting_post_id_str'])) : ?>
          <a href="https://facebook.com/<?php echo $item['attachments']['facebook_post']['commenting_post_id_str'] ?>?comment_id=<?php echo end(explode('_', $item['attachments']['facebook_post']['post_id_str'])) ?>" target="_blank">
        <?php else : ?>
          <a href="https://facebook.com/<?php echo $item['attachments']['facebook_post']['post_id_str'] ?>" target="_blank">
        <?php endif; ?>
          <span class="flockler-article__fb-attachment__profile__date">
            <?php echo date_i18n(get_option('date_format'), strtotime($item['attachments']['facebook_post']['created_time'])) ?>
          </span>
        </a>
      </span>
    </div>
  </div>
  <div class="flockler-article__fb-attachment__body">
    <p class="flockler-article__fb-attachment__message">
      <?php echo nl2br($item['attachments']['facebook_post']['message']) ?>
    </p>
  </div>
  <div class="flockler-article__fb-attachment__attachment">
    <?php if ($item['attachments']['facebook_post']['post_type'] == 'photo') : ?>
      <figure class="flockler-article__fb-attachment__attachment__photo">
        <img src="<?php echo $item['attachments']['facebook_post']['picture'] ?>" class="flockler-article__fb-attachment__photo__img" alt="" />
      </figure>
    <?php elseif ($item['attachments']['facebook_post']['picture'] && $item['attachments']['facebook_post']['post_type'] == 'video') : ?>
      <div id="fb-root"></div>
      <script>
        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6";
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      </script>
      <div class="fb-video" data-href="<?php echo $item['attachments']['facebook_post']['link'] ?>" data-width="500" data-show-text="false"></div>
    <?php elseif ($item['attachments']['facebook_post']['post_type'] == 'link') : ?>
      <a href="http://facebook.com/<?php echo $item['attachments']['facebook_post']['post_id_str'] ?>" class="flockler-article__fb-attachment__link" target="_blank">
        <?php if (!empty($item['attachments']['facebook_post']['picture'])) : ?>
          <figure class="flockler-article__fb-attachment__link__cover" style="background-image: url(<?php echo $item['attachments']['facebook_post']['picture'] ?>);">
            <img src="<?php echo $item['attachments']['facebook_post']['picture'] ?>" alt="" />
          </figure>
        <?php endif; ?>
        <div class="flockler-article__fb-attachment__link__body">
          <span class="flockler-article__fb-attachment__link__title">
            <?php echo $item['attachments']['facebook_post']['link_name'] ?>
          </span>
          <p class="flockler-article__fb-attachment__link__description">
            <?php echo nl2br($item['attachments']['facebook_post']['link_description']) ?>
          </p>
          <span class="flockler-article__fb-attachment__link__domain">
            <?php echo $item['attachments']['facebook_post']['link_caption'] ?>
          </span>
        </div>
      </a>
    <?php endif; ?>
  </div>
</div>

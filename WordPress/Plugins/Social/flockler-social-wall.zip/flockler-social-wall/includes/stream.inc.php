<?php

if (empty($item) || empty($settings)) {
    // Render nothing.
    return;
}

$itemWidth = $settings['itemWidth'] === null ? '' : 'style="width: ' . $settings['itemWidth'] . ';"';

switch($item['type']) {
    case 'instagram':
        require('wall_items/instagram.inc.php');
        break;
    case 'tweet':
        require('wall_items/tweet.inc.php');
        break;
    case 'facebook_post':
        require('wall_items/facebook.inc.php');
        break;
    case 'video':
        require('wall_items/video.inc.php');
        break;
    case 'link':
        if (!empty($item['attachments']) && !empty($item['attachments']['link'])) {
            require('wall_items/link.inc.php');
        } else {
            require('wall_items/link_old.inc.php');
        }
        break;
    case 'linkedin':
        require('wall_items/linkedin.inc.php');
        break;
    case 'pinterest':
        if (!empty($item['attachments']) && !empty($item['attachments']['pinterest_item'])) {
            require('wall_items/pinterest.inc.php');
            break;
        }
    default:
        require('wall_items/article.inc.php');
        break;
}

<?php
  // If not called from WordPress itself, exit silently
  if (!defined('WP_ADMIN')) {
    die();
  }

  // The $hooks array should be present and defined in the context this file is called on.
  if (!isset($hooks) || !is_array($hooks)) {
    $hooks = array();
  }
?>

<div class="wrap">
  <h2>Flockler webhooks</h2>

  <?php if (empty($hooks)) : ?>
    <p>
      <a href="https://flockler.com/login" target="_blank">Log in to Flockler</a> or <a href="https://flockler.com/free-trial?form[type]=wordpress" target="_blank">create a new account</a> to collate social content and display user-generated content on your WordPress site.
    </p>
  <?php endif; ?>

  <table class="wp-list-table widefat striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Webhook URL</th>
        <th>Secret</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($hooks as $hook) : ?>
        <tr data-id="<?php echo $hook['id']; ?>" data-name="<?php echo $hook['name']; ?>" data-secret="<?php echo $hook['secret']; ?>">
          <td><?php echo $hook['id']; ?></td>
          <td><?php echo $hook['name']; ?></td>
          <td><?php echo get_site_url() . "/?flockler-hook=<strong>" . $hook['id']; ?></strong></td>
          <td><?php echo $hook['secret']; ?></strong></td>
          <td>
            <button type="button" class="button flockler_webhook_update_button">Edit</button>
            <button type="button" class="button flockler_webhook_delete_button">Delete</button>
          </td>
        </tr>
      <?php endforeach ?>
      <?php if (empty($hooks)) : ?>
        <tr>
          <td colspan="3">No webhooks yet. Add a webhook below and add it to <a href="https://flockler.com/newsroom" target="_blank">your Flockler site’s</a> “Settings” > “Webhooks”.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <form method="post" action="">
    <input type="hidden" name="action" value="add">
    <table class="form-table">
      <tr>
        <th>
          <label for="flockler_webhook_add_name">
            Add a webhook:
          </label>
        </th>
        <td>
          <input class="regular-text" type="text" placeholder="Example Webhook Name"
                 id="flockler_webhook_add_name" name="webhook_name">
          <input id="flockler_webhook_add_button" class="button button-primary" type="submit" value="Add">
        </td>
      </tr>
    </table>
  </form>

  <h2>Settings</h2>
  <form method="post" action="">
    <input type="hidden" name="action" value="set_settings">
    <table class="form-table">
      <tr>
        <th>
          Flockler post display
        </th>
        <td>
          <fieldset>
            <div>
              <label>
                <input type="radio" value="1" name="in_blog"
                    <?php echo $settings['in_blog'] ? 'checked="checked"' : '' ?>>
                Automatically display Flockler posts alongside other main blog content
              </label>
            </div>
            <div>
              <label>
                <input type="radio" value="0" name="in_blog"
                    <?php echo !$settings['in_blog'] ? 'checked="checked"' : '' ?>>
                Only display Flockler posts in walls generated with the shortcode
              </label>
            </div>
          </fieldset>
        </td>
      </tr>
      <tr>
        <th>
          Post image width
        </th>
        <td>
          <input class="regular-text" type="text" placeholder="600" id="flockler_image_width" name="image_width" value="<?php echo isset($settings['image_width']) ? $settings['image_width'] : '' ?>">
        </td>
      </tr>
      <tr>
        <th>
          Wall Share Icons
        </th>
        <td>
          <div>
            <label>
              <input type="checkbox" name="twitter_share_button" <?php echo $settings['twitter_share_button'] ? 'checked="checked"' : '' ?> />
              Show Twitter share icon
            </label>
          </div>
          <div>
            <label>
              <input type="checkbox" name="facebook_share_button" <?php echo $settings['facebook_share_button'] ? 'checked="checked"' : '' ?> />
              Show Facebook share icon
            </label>
          </div>
          <div>
            <label>
              <input type="checkbox" name="linkedin_share_button" <?php echo $settings['linkedin_share_button'] ? 'checked="checked"' : '' ?> />
              Show LinkedIn share icon
            </label>
          </div>
        </td>
      </tr>
      <tr>
        <th>
          Wall Item Timestamps
        </th>
        <td>
          <div>
            <label>
              <input type="checkbox" name="wall_item_timestamps" <?php echo $settings['wall_item_timestamps'] ? 'checked="checked"' : '' ?> />
              Show timestamps on wall items
            </label>
          </div>
        </td>
      </tr>
    </table>
    <p class="submit">
      <input class="button" type="submit" value="Save">
    </p>
  </form>
</div>

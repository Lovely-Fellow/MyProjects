<div class="flockler-article-body">
    <?php if (isset($item['attachments']['tweet']) && isset($item['attachments']['tweet']['oembed'])) : ?>
        <p class="flockler-article__attachment flockler-article__attachment--tweet">
            <?php echo $item['attachments']['tweet']['oembed'] ?>
        </p>
    <?php elseif (isset($item['attachments']['instagram_item'])) : ?>
        <p class="flockler-article__attachment flockler-article__attachment--instagram">
            <?php require('attachments/instagram.inc.php'); ?>
        </p>
    <?php elseif (isset($item['attachments']['video'])) : ?>
        <p class="flockler-article__attachment flockler-article__attachment--video">
            <iframe src="<?php echo $item['attachments']['video']['embed_src'] ?>" class="flockler-article__attachment__iframe flockler-article__attachment__iframe--video" frameborder="0" allowfullscreen></iframe>
        </p>
    <?php elseif (isset($item['attachments']['facebook_post'])) : ?>
        <div class="flockler-article__attachment flockler-article__attachment--facebook">
            <?php require('attachments/facebook.inc.php'); ?>
        </div>
    <?php endif; ?>

    <?php echo $item['body'] ?>
</div>

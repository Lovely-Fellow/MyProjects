<?php
class AmazonAutoLinks_MetaBox_TagOptions extends AmazonAutoLinks_MetaBox_TagOptions_ {}
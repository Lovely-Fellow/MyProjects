<?php
class AmazonAutoLinks_Form_Tag extends AmazonAutoLinks_Form_Tag_ {}
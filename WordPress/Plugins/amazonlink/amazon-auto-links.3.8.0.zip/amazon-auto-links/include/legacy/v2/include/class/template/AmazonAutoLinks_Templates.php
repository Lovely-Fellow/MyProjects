<?php
/**    
    Handles templates that display fetched data.
    
    @package            Amazon Auto Links
    @copyright            Copyright (c) 2013, Michael Uno
    @authorurl            http://michaeluno.jp
    @license            http://opensource.org/licenses/gpl-2.0.php GNU Public License
    @since                2.0.0
 */
class AmazonAutoLinks_Templates extends AmazonAutoLinks_Templates_ {}
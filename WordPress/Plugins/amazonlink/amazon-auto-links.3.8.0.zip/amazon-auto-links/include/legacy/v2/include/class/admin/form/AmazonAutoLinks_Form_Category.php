<?php
class AmazonAutoLinks_Form_Category extends AmazonAutoLinks_Form_Category_ {}
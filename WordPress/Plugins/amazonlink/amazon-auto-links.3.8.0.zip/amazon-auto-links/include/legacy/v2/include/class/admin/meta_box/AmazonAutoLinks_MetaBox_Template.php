<?php
class AmazonAutoLinks_MetaBox_Template extends AmazonAutoLinks_MetaBox_Template_ {}
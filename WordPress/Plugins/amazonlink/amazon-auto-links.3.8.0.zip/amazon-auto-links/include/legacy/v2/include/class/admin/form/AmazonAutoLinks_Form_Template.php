<?php
class AmazonAutoLinks_Form_Template extends AmazonAutoLinks_Form_Template_ {}
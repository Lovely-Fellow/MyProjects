<?php
class AmazonAutoLinks_ListTable extends AmazonAutoLinks_ListTable_ {}
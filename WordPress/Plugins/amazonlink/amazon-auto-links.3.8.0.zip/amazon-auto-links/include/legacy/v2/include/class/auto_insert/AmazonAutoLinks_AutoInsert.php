<?php
class AmazonAutoLinks_AutoInsert extends AmazonAutoLinks_AutoInsert_ {}
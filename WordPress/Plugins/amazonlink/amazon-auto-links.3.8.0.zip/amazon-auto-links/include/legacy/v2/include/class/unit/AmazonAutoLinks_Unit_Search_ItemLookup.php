<?php
class AmazonAutoLinks_Unit_Search_ItemLookup extends AmazonAutoLinks_Unit_Search_ItemLookup_ {}

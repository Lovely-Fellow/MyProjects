<?php
/**
 * Provides the definitions of form fields.
 * 
 * @since           3.2.0
 */
class AmazonAutoLinks_FormFields_URLUnit_Advanced extends AmazonAutoLinks_FormFields_ItemLookupUnit_Advanced {}
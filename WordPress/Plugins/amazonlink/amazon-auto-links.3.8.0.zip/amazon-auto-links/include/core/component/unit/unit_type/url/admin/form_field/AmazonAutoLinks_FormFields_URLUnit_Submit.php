<?php
/**
 * Provides the definitions of form fields for the 'url' unit type.
 * 
 * @since           3  
 */
class AmazonAutoLinks_FormFields_URLUnit_Submit extends AmazonAutoLinks_FormFields_Unit_WizardSubmit {

    protected $_sUnitType = 'url';

}
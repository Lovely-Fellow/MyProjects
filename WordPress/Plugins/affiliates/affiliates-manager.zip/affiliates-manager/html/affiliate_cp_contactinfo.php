<div class="aff-wrap">
<?php
include WPAM_BASE_DIRECTORY . "/html/affiliate_cp_nav.php";
?>
<div class="wrap">
	<?php include WPAM_BASE_DIRECTORY . '/html/contact_info.php'; ?>
</div>
</div>
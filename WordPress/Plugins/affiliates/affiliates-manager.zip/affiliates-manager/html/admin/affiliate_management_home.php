<div class="wrap">
<h2><?php _e( 'Affiliate Management Control Panel', 'affiliates-manager' ) ?></h2>
</div>
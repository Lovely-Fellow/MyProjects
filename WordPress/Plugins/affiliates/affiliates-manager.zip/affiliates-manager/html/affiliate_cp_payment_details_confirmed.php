<div class="wrap">
    <h2><?php _e('Confirmed', 'affiliates-manager') ?></h2>
    <h3><?php _e('Your payment details have been submitted.', 'affiliates-manager') ?></h3>
    <p class="wpam-cp-paymen-details-confirmed-msg">
        <?php printf(__('Now would be a great time to go pick <a href="%s">some creatives</a> and get started.', 'affiliates-manager'), $this->viewData['creativesLink']) ?>
    </p>	

</div>

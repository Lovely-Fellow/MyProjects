<?php
/**
 * @author John Hargrove
 * 
 * Date: Jun 28, 2010
 * Time: 9:40:17 PM
 */

class WPAM_Data_Models_ActionModel {
}

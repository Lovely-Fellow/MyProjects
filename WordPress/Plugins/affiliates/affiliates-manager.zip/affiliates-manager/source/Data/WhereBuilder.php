<?php
/**
 * @author John Hargrove
 * 
 * Date: May 20, 2010
 * Time: 10:33:27 PM
 */

class WPAM_Data_WhereBuilder
{
	public function buildWhere(array $params)
	{
		$query = "";
		
	}
}

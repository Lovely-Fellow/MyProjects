<?php
/* These strings are generated dynamically. We have mentioned them here so the plugin can at least translate the strings. */
//affiliate_register_form.php
_e( 'Address Line 1', 'affiliates-manager' );
_e( 'Address Line 2', 'affiliates-manager' );
_e( 'Zip Code', 'affiliates-manager' );
_e( 'Company Name', 'affiliates-manager' );
_e( 'Website URL', 'affiliates-manager' );

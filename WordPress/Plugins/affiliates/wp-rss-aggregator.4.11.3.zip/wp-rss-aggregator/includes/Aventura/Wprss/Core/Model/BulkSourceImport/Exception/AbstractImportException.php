<?php

namespace Aventura\Wprss\Core\Model\BulkSourceImport\Exception;

/**
 * Common functionality for feed source import exceptions.
 *
 * @since 4.11
 */
class AbstractImportException extends \RuntimeException
{
}

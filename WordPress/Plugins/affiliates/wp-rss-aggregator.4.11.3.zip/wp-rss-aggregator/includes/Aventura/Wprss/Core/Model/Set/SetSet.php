<?php

namespace Aventura\Wprss\Core\Model\Set;

/**
 * A set of sets.
 *
 * @since 4.10
 */
class SetSet extends AbstractGenericSetSet
{
}
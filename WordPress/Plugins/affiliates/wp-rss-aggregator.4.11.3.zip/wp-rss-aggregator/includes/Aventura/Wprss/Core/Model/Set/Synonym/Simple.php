<?php

namespace Aventura\Wprss\Core\Model\Set\Synonym;

/**
 * A simple set of synonyms.
 *
 * @since 4.10
 */
class Simple extends AbstractGenericSynonymSet implements SynonymSetInterface
{
}

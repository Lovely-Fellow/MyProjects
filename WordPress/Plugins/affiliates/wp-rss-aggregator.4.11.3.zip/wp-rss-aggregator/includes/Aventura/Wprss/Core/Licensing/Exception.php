<?php

namespace Aventura\Wprss\Core\Licensing;

use Aventura\Wprss\Core;

/**
 * When something goes wrong with WPRA licensing.
 * 
 * @since 4.8.1
 */
class Exception extends Core\Exception
{
}
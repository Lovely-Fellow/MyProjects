<?php

namespace Aventura\Wprss\Core;

use Aventura\Wprss\Core;

/**
 * Manages WPRA Core events.
 *
 * @since 4.11
 */
class EventManager extends Core\Model\Event\EventManagerAbstract
{
}
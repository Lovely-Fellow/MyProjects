jQuery(document).ready(function(){
		jQuery('.al_subhead1,.al_subhead').click(function(){
			jQuery(this).next('.al_options').toggle();
		});
});

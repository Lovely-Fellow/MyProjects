const { __ } = wp.i18n;
const {
    Button,
    Disabled,
    ServerSideRender,
    Toolbar,
} = wp.components;
const {
	RichTextToolbarButton
} = wp.editor;
const { registerBlockType } = wp.blocks;
const { registerFormatType } = wp.richText;
const { Fragment, Component } = wp.element;
const { dispatch } = wp.data;
const { addFilter } = wp.hooks;

// const AffiliateLink = {
//     id: 'easy-affiliate-link',
//     title: 'Easy Affiliate Link',
//     type: 'image',
//     icon: 'admin-links',
//     edit( { onSave } ) {
//         return (
//             <a href="">Edit EAFL</a>
//         );
//     },
//     save() {
//         return (
//             <a href="#">Saved EAFL</a>
//         );
//     }
// }

// const { registerToken } = dispatch( 'core/editor' );
// registerToken( 'easy-affiliate-link', AffiliateLink );

registerFormatType( 'easy-affiliate-links/link', {
	title: __( 'Affiliate Link' ),
	tagName: 'a',
	className: 'eafl',
	attributes: {
		url: 'href',
		target: 'target',
	},
	edit: class LinkEdit extends Component {
		constructor() {
			super( ...arguments );

			this.addLink = this.addLink.bind( this );
			this.stopAddingLink = this.stopAddingLink.bind( this );
			this.onRemoveFormat = this.onRemoveFormat.bind( this );
			this.state = {
				addingLink: false,
			};
		}

		addLink() {
			const { value, onChange } = this.props;
			const text = getTextContent( slice( value ) );

			if ( text && isURL( text ) ) {
				onChange( applyFormat( value, { type: name, attributes: { url: text } } ) );
			} else {
				this.setState( { addingLink: true } );
			}
		}

		stopAddingLink() {
			this.setState( { addingLink: false } );
		}

		onRemoveFormat() {
			const { value, onChange } = this.props;

			onChange( removeFormat( value, name ) );
		}

		render() {
			const { isActive, activeAttributes, value, onChange } = this.props;

			return (
				<Fragment>
					{ isActive && <RichTextToolbarButton
						name="link"
						icon="editor-unlink"
						title={ __( 'Unlink Affiliate' ) }
						onClick={ this.onRemoveFormat }
						isActive={ isActive }
					/> }
					{ ! isActive && <RichTextToolbarButton
						name="link"
						icon="admin-links"
						title={ __( 'Affiliate Link' ) }
						onClick={ this.addLink }
						isActive={ isActive }
					/> }
					LinkUI
				</Fragment>
			);
		}
	},
});
var eafl_admin = eafl_admin || {};

jQuery(document).ready(function($) {
	jQuery('.eafl-settings').find('select').select2_eafl();
});
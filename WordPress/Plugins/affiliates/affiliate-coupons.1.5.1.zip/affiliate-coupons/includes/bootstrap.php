<?php
/**
 * Bootstrap
 *
 * @package     AffiliateCoupons\Vendor
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load Meta Box
 */
require_once AFFCOUPS_PLUGIN_DIR . 'includes/vendor/meta-box/meta-box.php';
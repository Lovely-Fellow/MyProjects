### Bootstrap and LibreICONS theme for elFinder

This is a simple Theme for elFinder that changes only the Styling and Icons, the theme doesn't interfere with elFinder's Functionality.

To add, simply copy the `theme-bootstrap-libreicons-svg.css` to elFinder's css folder, and copy the SVG Icons to elFinder's `img` folder.

Then include the css file after elFinder's css include. This theme simply override's elFinder's classes to look more like Bootstrap.

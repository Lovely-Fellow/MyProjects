    <div class="wrap">
        <h2 style="margin-bottom: 25px;">Mass Payment Transactions</h2>
        <table id="example2" class="display" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th width="10%">ID</th>
                    <th>E-mail</th>
                    <th width="10%">Amount</th>
                    <th width="10%">Currency</th>
                    <th>Status</th>
                    <th>Added</th>
                    <th>Modified</th>
                    <th width="10%">Referrals</th>
                </tr>
            </thead>
     
            <tfoot>
                <tr>
                    <th width="10%">ID</th>
                    <th width="35%">E-mail</th>
                    <th width="10%">Amount</th>
                    <th width="10%">Currency</th>
                    <th>Status</th>
                    <th>Added</th>
                    <th>Modified</th>
                    <th width="10%">Referrals</th>
                </tr>
            </tfoot>
        </table>
    </div>

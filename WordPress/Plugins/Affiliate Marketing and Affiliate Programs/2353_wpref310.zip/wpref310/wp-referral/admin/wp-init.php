<?php
add_action( 'admin_menu', 'wp_referral_menu' );
function wp_referral_menu() {
    $my_page = add_menu_page( 'WordPress Referral', 'WP Referral', 'manage_options', 'wp-referral', 'wp_referral' );
    add_action( 'load-' . $my_page, 'load_wp_referral_admin_js' );
	//add_menu_page('WordPress Referral', 'WP Referral', 'manage_options', 'wp-referral', 'wp_referral');
}
function load_wp_referral_admin_js(){
	add_action( 'admin_enqueue_scripts', 'enqueue_wp_referral_admin_js' );
}
function enqueue_wp_referral_admin_js(){
	wp_enqueue_script( 'dataTables-js', plugins_url( 'js/jquery.dataTables.min.js' , dirname(__FILE__) ) );
	wp_enqueue_script( 'custom-js', plugins_url( 'js/custom.js' , dirname(__FILE__) ) );
    wp_enqueue_script( 'bootstrap-pingoomp-js', plugin_dir_url( __FILE__ ) . 'js/bootstrap.min.js' );
    wp_enqueue_script( 'pingoomp-functions-js', plugin_dir_url( __FILE__ ) . 'js/functions.js' );
}
function wpreferral_load_scripts() {
	wp_register_style( 'wpreferralStylesheet', plugins_url('/css/jquery.dataTables.min.css', __FILE__) );	
	wp_enqueue_style( 'wpreferralBootstrapStylesheet', plugins_url('/css/bootstrap.css', __FILE__) );	
    wp_enqueue_style( 'wpreferralStylesheet' );
	add_thickbox();
}
add_action('admin_enqueue_scripts', 'wpreferral_load_scripts');
?>
<?php
    $check_submit = 'check_submit_hidden';

    $cookie_opt_name = 'wp_referral_cookie_life';
    $cookie_data_field_name = 'wp_referral_cookie_life';
    $cookie_opt_val = get_option( $cookie_opt_name );
        
    $notif_opt_name = 'wp_referral_notif';
    $notif_data_field_name = 'wp_referral_notif';
    $notif_opt_val = get_option( $notif_opt_name );
        
    $regurl_opt_name = 'wp_referral_register_url';
    $regurl_data_field_name = 'wp_referral_register_url';
    $regurl_opt_val = get_option( $regurl_opt_name );
        
    $wpreffb_opt_name = 'wp_referral_fb';
    $wpreffb_data_field_name = 'wp_referral_fb';
    $wpreffb_opt_val = get_option( $wpreffb_opt_name );
        
    $wprefedit_opt_name = 'wp_referral_wprefedit';
    $wprefedit_data_field_name = 'wp_referral_wprefedit';
    $wprefedit_opt_val = get_option( $wprefedit_opt_name );
        
    $wprefmobileapi_opt_name = 'wp_referral_wprefmobileapi';
    $wprefmobileapi_data_field_name = 'wp_referral_wprefmobileapi';
    $wprefmobileapi_opt_val = get_option( $wprefmobileapi_opt_name );
    
    $wprefamount_ccode_opt_name = 'wp_referral_amount_ccode';
    $wprefamount_ccode_data_field_name = 'wp_referral_amount_ccode';
    $wprefamount_ccode_opt_val = get_option( $wprefamount_ccode_opt_name );
    $amount_ccode = $wprefamount_ccode_opt_val;
    
    $wprefamount_opt_name = 'wp_referral_amount';
    $wprefamount_data_field_name = 'wp_referral_amount';
    $wprefamount_opt_val = get_option( $wprefamount_opt_name );
    
    $wprefaffcheck_opt_name = 'wp_referral_affcheck';
    $wprefaffcheck_data_field_name = 'wp_referral_affcheck';
    $wprefaffcheck_opt_val = get_option( $wprefaffcheck_opt_name );
    
    $ns_opt_name = 'wp_referral_notif_s';
    $ns_data_field_name = 'wp_referral_notif_s';
    $ns_opt_val = get_option( $ns_opt_name );
    
    $nb_opt_name = 'wp_referral_notif_b';
    $nb_data_field_name = 'wp_referral_notif_b';
    $nb_opt_val = get_option( $nb_opt_name );
    
    /*
    $wprefpayfrom_opt_name = 'wp_referral_payfrom';
    $wprefpayfrom_data_field_name = 'wp_referral_payfrom';
    $wprefpayfrom_opt_val = get_option($wprefpayfrom_opt_name);
    */
    
    
        
    if( isset($_POST[ $check_submit ]) && $_POST[ $check_submit ] == 'Y' ) {
        $regurl_opt_val = $_POST[ $regurl_data_field_name ];
        update_option( $regurl_opt_name, $regurl_opt_val );
        $cookie_opt_val = $_POST[ $cookie_data_field_name ];
        update_option( $cookie_opt_name, $cookie_opt_val );
        $notif_opt_val = $_POST[ $notif_data_field_name ];
        update_option( $notif_opt_name, $notif_opt_val );
        $wpreffb_opt_val = $_POST[ $wpreffb_data_field_name ];
        update_option( $wpreffb_opt_name, $wpreffb_opt_val );
        $wprefedit_opt_val = $_POST[ $wprefedit_data_field_name ];
        update_option( $wprefedit_opt_name, $wprefedit_opt_val );
        $wprefmobileapi_opt_val = $_POST[ $wprefmobileapi_data_field_name ];
        update_option( $wprefmobileapi_opt_name, $wprefmobileapi_opt_val );
        $wprefamount_ccode_opt_val = $_POST[ $wprefamount_ccode_data_field_name ];
        $amount_ccode = $wprefamount_ccode_opt_val;
        update_option( $wprefamount_ccode_opt_name, $wprefamount_ccode_opt_val );
        $wprefamount_opt_val = $_POST[ $wprefamount_data_field_name ];
        update_option( $wprefamount_opt_name, $wprefamount_opt_val );
        $wprefaffcheck_opt_val = $_POST[ $wprefaffcheck_data_field_name ];
        update_option( $wprefaffcheck_opt_name, $wprefaffcheck_opt_val );
        //$wprefpayfrom_opt_val = $_POST[ $wprefpayfrom_data_field_name ];
        //update_option( $wprefpayfrom_opt_name, $wprefpayfrom_opt_val );

        $ns_opt_val = $_POST[ $ns_data_field_name ];
        update_option( $ns_opt_name, $ns_opt_val );
        $nb_opt_val = $_POST[ $nb_data_field_name ];
        update_option( $nb_opt_name, $nb_opt_val );
        	
?>



<div class="updated"><p><strong>Settings saved.</strong></p></div>

<?php } 
    if($wprefaffcheck_opt_val=='' || $wprefaffcheck_opt_val=='0' || $wprefaffcheck_opt_val==null || !isset($wprefaffcheck_opt_val)) { update_option( $wprefaffcheck_opt_name, '1'); }
    if($wprefamount_opt_val=='' || $wprefamount_opt_val==null || !isset($wprefamount_opt_val)) { update_option( $wprefamount_opt_name, '10'); }
    if($wprefamount_ccode_opt_val=='' || $wprefamount_ccode_opt_val==null || !isset($wprefamount_ccode_opt_val)) { update_option( $wprefamount_ccode_opt_name, 'USD'); }


if($ns_opt_val=='' || $ns_opt_val==null || !isset($ns_opt_val)) { update_option( $ns_opt_name, 'Good News!'); }
if($nb_opt_val=='' || $nb_opt_val==null || !isset($nb_opt_val)) { update_option( $nb_opt_name, '{user_nicename} just signed up! Keep up the good work!'); }



$cookie_life = get_option('wp_referral_cookie_life');
if ($cookie_life == 0) { 
	$cookie_life_text = "DISABLED";
} else {
	$cookie_life_text = "set to ".$cookie_life." days";
}
$regurl_text = get_option('wp_referral_register_url');
if (!isset($regurl_text) || $regurl_text == '') {
	$regurl_text = '/wp-login.php?action=register';
}
$wpreffb_text = get_option('wp_referral_fb');
if (!isset($wpreffb_text)) {
	$wpreffb_text = 1;
}
if ($wpreffb_text == 1) { 
	$wpreffb_text_html = "ENABLED";
} else {
	$wpreffb_text_html = "DISABLED";
}
$wprefedit_check = get_option('wp_referral_wprefedit');
if (!isset($wprefedit_check)) {
	$wprefedit_check = 'no';
}
if ($wprefedit_check == 'yes') { 
	$wprefedit_text_html = "ENABLED";
} else {
	$wprefedit_text_html = "DISABLED";
}
$wprefmobileapi_check = get_option('wp_referral_wprefmobileapi');
if (!isset($wprefmobileapi_check) || $wprefmobileapi_check == '') {
	    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randstring = '';
    for ($i = 0; $i < 4; $i++) {
        $randstring .= $characters[rand(0, strlen($characters))];
    }
    $wprefmobileapi_opt_val = $randstring;
    update_option( $wprefmobileapi_opt_name, $wprefmobileapi_opt_val );
    
}


$notif_check = get_option('wp_referral_notif');
if (!isset($notif_check)) {
	$notif_check = 'no';
}
if ($notif_check == 'yes') { 
	$notif_check_text_html = "ENABLED";
} else {
	$notif_check_text_html = "DISABLED";
}



 ?>
<form name="form1" method="post" action="">
	<input type="hidden" name="<?php echo $check_submit; ?>" value="Y">
	<h2>General Settings</h2><br><img src="http://www.lolinez.com/erw.jpg">
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row" class="titledesc">WP Referral Cookie life</th>
				<td><input type="number" name="<?php echo $cookie_data_field_name; ?>" value="<?php echo $cookie_opt_val; ?>" size="5"><br /><em class="wprmicro">Right now you have WP Referral tracking cookie <?php echo $cookie_life_text; ?>.</em></td>
			</tr>
			<tr valign="top">
				<th scope="row" class="titledesc">Can admin edit Referral ID?</th>
				<td><select name="<?php echo $wprefedit_data_field_name; ?>" id="<?php echo $wprefedit_data_field_name; ?>">
  <option value="no" <?php if ($wprefedit_check == 'no') { echo 'selected="selected"'; } ?>>No</option>
  <option value="yes" <?php if ($wprefedit_check == 'yes') { echo 'selected="selected"'; } ?>>Yes</option>
</select><br /><em class="wprmicro">Right now you have <?php echo $wprefedit_text_html; ?> this option.</em></td>
			</tr>
			<tr valign="top">
				<th scope="row" class="titledesc">Registration URL</th>
				<td><?php echo site_url(); ?> <input type="text" name="<?php echo $regurl_data_field_name; ?>" value="<?php echo $regurl_opt_val; ?>" size="40" placeholder="<?php echo $regurl_text; ?>"><br /><em class="wprmicro">Right now you have WP Registration URL set as "<?php echo $regurl_text; ?>".(Please edit your registration URL to suit your needs. For example if you have BuddyPress you need to set the value to /register/ etc.)</em></td>
			</tr>
			<tr valign="top">
				<th scope="row" class="titledesc">New referral notification</th>
				<td><select name="<?php echo $notif_data_field_name; ?>" id="<?php echo $notif_data_field_name; ?>">
  <option value="no" <?php if ($notif_check == 'no') { echo 'selected="selected"'; } ?>>No</option>
  <option value="yes" <?php if ($notif_check == 'yes') { echo 'selected="selected"'; } ?>>Yes</option>
</select><br /><em class="wprmicro">Should users be notified when a referral registers? Right now you have <?php echo $notif_check_text_html; ?> this option.</em><br /><br /><input type="text" placeholder="Notification Subject"  name="<?php echo $ns_data_field_name; ?>" value="<?php echo $ns_opt_val; ?>" /><br /><textarea style="width: 50%; margin-top: 10px; height: 100px;" placeholder="Notification Body"  name="<?php echo $nb_data_field_name; ?>" ><?php echo $nb_opt_val; ?></textarea></td>
			</tr>
		</tbody>
	</table>
	<h2>Rewarding Settings</h2>
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row" class="titledesc">Pay affiliates</th>
				<td>
					<select id="<?php echo $wprefamount_ccode_data_field_name; ?>" name="<?php echo $wprefamount_ccode_data_field_name; ?>">
						<option value="USD"<?php if($amount_ccode=='USD'){echo ' selected="selected"';} ?>>USD - U.S. Dollars</option>
						<option value="AUD"<?php if($amount_ccode=='AUD'){echo ' selected="selected"';} ?>>AUD - Australian Dollars</option>
						<option value="BRL"<?php if($amount_ccode=='BRL'){echo ' selected="selected"';} ?>>BRL - Brazilian Reais</option>
						<option value="GBP"<?php if($amount_ccode=='GBP'){echo ' selected="selected"';} ?>>GBP - British Pounds</option>
						<option value="CAD"<?php if($amount_ccode=='CAD'){echo ' selected="selected"';} ?>>CAD - Canadian Dollars</option>
						<option value="CZK"<?php if($amount_ccode=='CZK'){echo ' selected="selected"';} ?>>CZK - Czech Koruny</option>
						<option value="DKK"<?php if($amount_ccode=='DKK'){echo ' selected="selected"';} ?>>DKK - Danish Kroner</option>
						<option value="EUR"<?php if($amount_ccode=='EUR'){echo ' selected="selected"';} ?>>EUR - Euros</option>
						<option value="HKD"<?php if($amount_ccode=='HKD'){echo ' selected="selected"';} ?>>HKD - Hong Kong Dollars</option>
						<option value="HUF"<?php if($amount_ccode=='HUF'){echo ' selected="selected"';} ?>>HUF - Hungarian Forints</option>
						<option value="ILS"<?php if($amount_ccode=='ILS'){echo ' selected="selected"';} ?>>ILS - Israeli New Shekels</option>
						<option value="JPY"<?php if($amount_ccode=='JPY'){echo ' selected="selected"';} ?>>JPY - Japanese Yen</option>
						<option value="MYR"<?php if($amount_ccode=='MYR'){echo ' selected="selected"';} ?>>MYR - Malaysian Ringgit</option>
						<option value="MXN"<?php if($amount_ccode=='MXN'){echo ' selected="selected"';} ?>>MXN - Mexican Pesos</option>
						<option value="TWD"<?php if($amount_ccode=='TWD'){echo ' selected="selected"';} ?>>TWD - New Taiwan Dollars</option>
						<option value="NZD"<?php if($amount_ccode=='NZD'){echo ' selected="selected"';} ?>>NZD - New Zealand Dollars</option>
						<option value="NOK"<?php if($amount_ccode=='NOK'){echo ' selected="selected"';} ?>>NOK - Norwegian Kroner</option>
						<option value="PHP"<?php if($amount_ccode=='PHP'){echo ' selected="selected"';} ?>>PHP - Philippine Pesos</option>
						<option value="PLN"<?php if($amount_ccode=='PLN'){echo ' selected="selected"';} ?>>PLN - Polish Zlotys</option>
						<option value="RUB"<?php if($amount_ccode=='RUB'){echo ' selected="selected"';} ?>>RUB - Russian Rubles</option>
						<option value="SGD"<?php if($amount_ccode=='SGD'){echo ' selected="selected"';} ?>>SGD - Singapore Dollars</option>
						<option value="SEK"<?php if($amount_ccode=='SEK'){echo ' selected="selected"';} ?>>SEK - Swedish Kronor</option>
						<option value="CHF"<?php if($amount_ccode=='CHF'){echo ' selected="selected"';} ?>>CHF - Swiss Francs</option>
						<option value="THB"<?php if($amount_ccode=='THB'){echo ' selected="selected"';} ?>>THB - Thai Baht</option>
						<option value="TRY"<?php if($amount_ccode=='TRY'){echo ' selected="selected"';} ?>>TRY - Turkish Liras</option>
					</select>
					<input type="number" name="<?php echo $wprefamount_data_field_name; ?>" value="<?php echo $wprefamount_opt_val; ?>" style="width: 100px;" /> for every <input type="number" name="<?php echo $wprefaffcheck_data_field_name; ?>" value="<?php echo $wprefaffcheck_opt_val; ?>" style="width: 100px;" /> referrals<br /><em class="wprmicro">Select how much will you pay. All payments will be made via PayPal.</em>
				</td>
			</tr>
			<tr valign="top" style="display: none;">
				<th scope="row" class="titledesc">Pay from</th>
				<td><input type="email" name="<?php //echo $wprefpayfrom_data_field_name; ?>" value="<?php // echo $wprefpayfrom_opt_val; ?>" size="40" placeholder="Your PayPal address"><br /><em class="wprmicro">Enter your PayPlay email address </em></td>
			</tr>
		</tbody>
	</table>
	<h2>Mobile App Settings</h2>
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row" class="titledesc">WP Referral Mobile access</th>
				<td><input type="text" name="<?php echo $wprefmobileapi_data_field_name; ?>" value="<?php echo $wprefmobileapi_opt_val; ?>" size="40" placeholder="The API Key will auto generate"><br /><em class="wprmicro">This is your mobile API Key. Use your API key for mobile access via <a href="https://play.google.com/store/apps/details?id=com.markessence.wp.affiliate.referral" target="_blank">WordPress Affiliate & Referral App</a>.</em></td>
			</tr>
		</tbody>
	</table>
	<h2>Other Settings</h2>
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row" class="titledesc">Facebook integration</th>
				<td><input type="text" name="<?php echo $wpreffb_data_field_name; ?>" value="<?php echo $wpreffb_opt_val; ?>" placeholder="Facebook App ID" /><br />
<em class="wprmicro">Facebook Share and Send are <?php echo $wpreffb_text_html; ?>. For better experience add your Facebook App ID from <a href="https://developers.facebook.com/apps" target="_blank">https://developers.facebook.com/apps</a>.</em></td>
			</tr>
		</tbody>
	</table>




<p class="submit">
<input type="submit" name="Submit" class="button-primary" value="<?php esc_attr_e('Save Changes') ?>" />
</p>
</form>
<div class="clear"><!-- --></div>

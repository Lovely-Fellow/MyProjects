<?php
    
    
    
    $totalusers = count_users();        
    if (isset($_GET['year'])) {
    	$year = $_GET['year'];
    } else {
	    $year = date('Y');
    }
    global $wpdb;
    global $post_id;
    for($i=1;$i<=12;$i++) {
	    $sql[$i] = "SELECT COUNT($wpdb->usermeta.meta_value) as referred FROM $wpdb->usermeta, $wpdb->users WHERE $wpdb->usermeta.meta_key='referral_id' AND $wpdb->usermeta.meta_value!='' AND $wpdb->usermeta.meta_value!=' ' AND $wpdb->usermeta.meta_value!='0' AND $wpdb->usermeta.user_id=$wpdb->users.ID AND MONTH($wpdb->users.user_registered)=$i AND YEAR($wpdb->users.user_registered)=$year";
	    //$sql[$i] = "SELECT COUNT($wpdb->usermeta.meta_value) as referred FROM $wpdb->usermeta, $wpdb->users WHERE $wpdb->usermeta.meta_key='referral_id' AND $wpdb->usermeta.meta_value=".get_current_user_id()." AND $wpdb->usermeta.user_id=$wpdb->users.ID AND MONTH($wpdb->users.user_registered)=$i AND YEAR($wpdb->users.user_registered)=$year";
	    $referred[$i] = $wpdb->get_var($sql[$i]);
    }
    for($i=1;$i<=12;$i++) {
	    $sql[$i] = "SELECT COUNT($wpdb->users.ID) as total FROM $wpdb->users WHERE MONTH($wpdb->users.user_registered)=$i AND YEAR($wpdb->users.user_registered)=$year";
	    $total[$i] = $wpdb->get_var($sql[$i]);
    }
    $chart = new Chart('LineChart');
    $data = array(
        'cols' => array(
                array('id' => '', 'label' => 'Month', 'type' => 'string'),
                array('id' => '', 'label' => 'New Users (total)', 'type' => 'number'),
                array('id' => '', 'label' => 'New Referred Users', 'type' => 'number'),
        ),
        'rows' => array(

                array('c' => array(array('v' => 'Jan'), array('v' => $total[1]), array('v' => $referred[1]))),
                array('c' => array(array('v' => 'Feb'), array('v' => $total[2]), array('v' => $referred[2]))),
                array('c' => array(array('v' => 'Mar'), array('v' => $total[3]), array('v' => $referred[3]))),
                array('c' => array(array('v' => 'Apr'), array('v' => $total[4]), array('v' => $referred[4]))),
                array('c' => array(array('v' => 'May'), array('v' => $total[5]), array('v' => $referred[5]))),
                array('c' => array(array('v' => 'Jun'), array('v' => $total[6]), array('v' => $referred[6]))),
                array('c' => array(array('v' => 'Jul'), array('v' => $total[7]), array('v' => $referred[7]))),
                array('c' => array(array('v' => 'Aug'), array('v' => $total[8]), array('v' => $referred[8]))),
                array('c' => array(array('v' => 'Sep'), array('v' => $total[9]), array('v' => $referred[9]))),
                array('c' => array(array('v' => 'Oct'), array('v' => $total[10]), array('v' => $referred[10]))),
                array('c' => array(array('v' => 'Nov'), array('v' => $total[11]), array('v' => $referred[11]))),
                array('c' => array(array('v' => 'Dec'), array('v' => $total[12]), array('v' => $referred[12]))),




        )
    );
    $chart->load(json_encode($data));
    $options = array('title' => 'Monthly New Users Registration Chart for '.$year, 'theme' => 'maximized', 'height' => 200);
    echo $chart->draw('chart', $options);
    
    
    global $wpdb;
    $yearslist = '';
    $sql = "SELECT DISTINCT(YEAR($wpdb->users.user_registered)) as theyear FROM $wpdb->users";
    $years = $wpdb->get_results($sql);
    foreach ($years as $theyear) {
	    $yearslist .= '<a href="'.admin_url().'admin.php?page=wp-referral&tab=stats&year='.$theyear->theyear.'">'.$theyear->theyear.'</a> ';
    }

?>
<p>Right now you have <?php $get_total_referrals = get_total_referrals('referral_id','0'); echo $get_total_referrals[0]; ?> successfully referred people by <?php echo $get_total_referrals[1]; ?> users. You have <?php echo $totalusers['total_users']-1; ?> users except yourself and <?php echo $get_total_referrals[1]; ?> of them are active affiliates.</p>
<h3>Registration Chart for <?php echo $year;?></h3>
<p>Below you have a general overview of monthly new users registration for year <?php echo $year;?>. You have registration activity in the following years: <?php echo $yearslist; ?>   </p>
<div id="chart"></div>
<h3>Active Affiliates (<?php echo $get_total_referrals[1]; ?>)</h3>






<table class="display" cellspacing="1" id="theTable">             
    <thead>
        <tr> 
            <th>ID</th> 
            <th align="left">Name</th> 
            <th align="left">Email</th> 
            <th align="right">Member Since</th> 
            <th>Referrals</th> 
            <th>Info</th> 
            <th align="right" style="display: none;">Pending<br /> <?php echo get_option('wp_referral_amount_ccode'); ?></th> 
            <th align="right" style="display: none;">Payed<br /> <?php echo get_option('wp_referral_amount_ccode'); ?></th> 
            <th align="right" style="display: none;">Lifetime<br /> <?php echo get_option('wp_referral_amount_ccode'); ?></th> 
            <th align="center" style="display: none;">Pay<br /> <?php echo get_option('wp_referral_amount_ccode'); ?></th> 
        </tr> 
    </thead>
<tbody>
<?php
    global $wpdb;
    $sql = "SELECT DISTINCT(meta_value) FROM $wpdb->usermeta WHERE meta_key='referral_id' AND meta_value!='0' AND meta_value!=''";
    $user_list = $wpdb->get_results($sql);
    $rowcount = 0;
    $count = 0;
    $html_table = '';
    $html_div_details = '';
    foreach ($user_list as $user) {
    	$user_info = get_userdata($user->meta_value);
        $html_table .= '<tr><td align="center">'.$user_info->ID.'</td><td>'.ucfirst(strtolower($user_info->first_name)).' '.ucfirst(strtolower($user_info->last_name)).'</td><td>'.strtolower($user_info->user_email).'</td><td align="right">'.date("F j, Y",strtotime($user_info->user_registered)).'</td><td align="center">'.get_total_referrals_per_user($user->meta_value).'</td><td align="center"><a href="../wp-content/plugins/wp-referral/wp-referral-id-details.php?KeepThis=true&id='.$user_info->ID.'&TB_iframe=true&height=400&width=600" class="thickbox" title="'.ucfirst(strtolower($user_info->first_name)).' '.ucfirst(strtolower($user_info->last_name)).' (ID '.$user_info->ID.') has referred '.get_total_referrals_per_user($user->meta_value).' users">list</a></td><td align="right" style="display: none;">0</td><td align="right" style="display: none;">0</td><td align="right" style="display: none;">'.((get_total_referrals_per_user($user->meta_value)/get_option('wp_referral_affcheck'))*get_option('wp_referral_amount')).'</td><td align="center" style="display: none;"><a href="" target="_blank">pay</a></td></tr>';
    }
    echo $html_table;
?>
</tbody> 
</table>
<?php	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( 'You do not have sufficient permissions to access this page.' );
	}
?>
<script type="text/javascript">
    //var commission = <?php echo get_option('pingoomp_value'); ?>;
    //var currency = '<?php echo get_option('pingoomp_currency'); ?>';
    var commission = <?php echo get_option('wp_referral_amount'); ?>;
    var currency = '<?php echo get_option('wp_referral_amount_ccode'); ?>';
</script>
<div class="wrap">
<h2>Pay your affiliates</h2>

<div id="alerts"></div>

<div id="comisiontotal" style="font-size: 14px; padding-top: 10px; padding-bottom: 10px; font-weight:bold">Total commission selected: 0 <?php echo get_option('wp_referral_amount_ccode'); ?></div>
<div id="payment" style="margin-bottom: 10px;"><input type="button" name="payment" class="btn btn-success" value="Send payment to PayPal" onclick="addToPendingPayments()" id="paymentbtn" /></div>
<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th width="10%">ID</th>
                <th width="35%">Name</th>
                <th width="35%">E-mail</th>
                <th width="10%">Referrals</th>
                <th width="10%">No.</th>
            </tr>
        </thead>
 
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>E-mail</th>
                <th>Referrals</th>
                <th>No.</th>
            </tr>
        </tfoot>
    </table>
</div>

	<h2>Free Android Assistant</h2>
	<p>You can now use a free Android app to have your most important data in your pocket! Please check out our <a href="https://play.google.com/store/apps/details?id=com.markessence.wp.affiliate.referral" target="_blank">WordPress Affiliate & Referral</a> App on Google Play Store.</p>
	<h2>Useful Information</h2>
    <p><strong>WordPress Referral Shortcodes </strong><br />
    <code>[referral_link]</code> - outputs link with referral code<br />
    <code>[referral_banner][/referral_banner]</code> - outputs link with referral code to any content placed inside (banner image, text, etc.)<br />
    <code>[referral_downline]</code> - outputs all referred people<br />
    <code>[referral_upline]</code> - outputs who referred the user<br />
    <code>[referral_fb]</code>- Facebook buttons with referral code for the default registration page<br />
    <code>[referral_fb_current]</code>- Facebook buttons with referral code for the current page / post / etc.<br />
    <code>[referral_twitter]</code>- Twitter button with referral code for the default registration page<br />
    <code>[referral_twitter_current]</code>- Twitter button with referral code for the current page / post / etc.<br />
    <code>[referral_googleplus]</code>- Google+ button with referral code for the default registration page<br />
    <code>[referral_googleplus_current]</code>- Google+ button with referral code for the current page / post / etc.<br />
    <code>[referral_linkedin]</code>- LinkedIn button with referral code for the default registration page<br />
    <code>[referral_linkedin_current]</code>- LinkedIn button with referral code for the current page / post / etc.<br />
    </p>
    <em>The shortcodes will work if a user is logged in. You can use these shortcodes on any page or post.</em>
    <p><strong>WordPress Referral Cookie</strong><br />
      To enable WordPress Referral cookie just enter an integer number in the Cookie Life settings field. That value is the cookie's life in days (how many days the cookie will be stored to track the referral). If you set the value to 0 (zero) the cookie tracking system is disabled.</p>
      <em class="wprmicro">It is important to know that if you disable WordPress Referral cookie the signup process will work and know the referral ONLY if the link is /wp-login.php?action=register&ref=CODE and the new user signs up directly into that page.</em>
      
    <p>Thank you for purchasing WP Referral plugin.</p>
    <p><a href="http://markessence.com" title="Web Design & Development, Graphic Design and SEO Consultancy" target="_blank">Markessence Website</a> <br /> <a href="http://codecanyon.net/user/markessence?ref=markessence" title="Markessence Envato Profile - Web Design & Development, Graphic Design and SEO Consultancy" target="_blank">Markessence Envato Profile</a><br /><a href="https://www.facebook.com/pages/Markessence/227623170718286" title="Markessence Facebook Profile - Web Design & Development, Graphic Design and SEO Consultancy" target="_blank">Markessence Facebook Profile</a></p>

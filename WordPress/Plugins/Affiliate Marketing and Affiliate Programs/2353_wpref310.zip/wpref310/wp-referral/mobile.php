<?php
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once( '../../../wp-load.php' );
$wprefmobileapi_check = get_option('wp_referral_wprefmobileapi');


if (isset($_GET["api"]) && $_GET["api"] == $wprefmobileapi_check) {

	global $wpdb;
	if (isset($_GET["userid"]) && $_GET["userid"] != "" && $_GET["userid"] != "0") {
		$downline = get_users(array('orderby' => 'registered', 'meta_key' => 'referral_id','meta_value'=>$_GET["userid"]));
		foreach ($downline as $referred) {
	    	$name = '';
	    	if (isset($referred->first_name) && $referred->first_name != '') {
		    	$name .= $referred->first_name;
	    	}
	    	if (isset($referred->last_name) && $referred->last_name != '') {
		    	$name .= ' '.$referred->last_name;
	    	}
	    	if ((!isset($referred->first_name) || $referred->first_name == '') && (!isset($referred->last_name) || $referred->last_name == '')) {
		    	$name .= $referred->user_nicename;
	    	}
	    	$refered_list[] = array(
				'id' => $referred->ID,
				'name' => $name,
				'email' => $referred->user_email,
				'registered' => $referred->user_registered
			);
		}
		$result[] = array(
			'access' => 'yes',
			'referrals' => $refered_list,
		);
	} else {
		// default listing
		$get_total_referrals = get_total_referrals('referral_id','0'); 
		$total_referrals = $get_total_referrals[0];
		$total_affiliates = $get_total_referrals[1];
		$total_users = count_users();
		$last_registration_id = $wpdb->get_var("SELECT user_id FROM $wpdb->usermeta WHERE meta_key='referral_id' AND meta_value!='0' AND meta_value!='' ORDER BY user_id DESC LIMIT 1");
		$last_registration_aff_id = $wpdb->get_var("SELECT meta_value FROM $wpdb->usermeta WHERE meta_key='referral_id' AND user_id =$last_registration_id");

		$last_registration_aff_info = get_userdata($last_registration_aff_id);
    	$last_registration_aff_name = '';
    	if (isset($last_registration_aff_info->first_name) && $last_registration_aff_info->first_name != '') {
	    	$last_registration_aff_name .= $last_registration_aff_info->first_name;
    	}
    	if (isset($last_registration_aff_info->last_name) && $last_registration_aff_info->last_name != '') {
	    	$last_registration_aff_name .= ' '.$last_registration_aff_info->last_name;
    	}
    	if ((!isset($last_registration_aff_info->first_name) || $last_registration_aff_info->first_name == '') && (!isset($last_registration_aff_info->last_name) || $last_registration_aff_info->last_name == '')) {
	    	$last_registration_aff_name .= $last_registration_aff_info->user_nicename;
    	}
		
		
		
		$last_registration_info = get_userdata($last_registration_id);
    	$last_registration_name = '';
    	if (isset($last_registration_info->first_name) && $last_registration_info->first_name != '') {
	    	$last_registration_name .= $last_registration_info->first_name;
    	}
    	if (isset($last_registration_info->last_name) && $last_registration_info->last_name != '') {
	    	$last_registration_name .= ' '.$last_registration_info->last_name;
    	}
    	if ((!isset($last_registration_info->first_name) || $last_registration_info->first_name == '') && (!isset($last_registration_info->last_name) || $last_registration_info->last_name == '')) {
	    	$last_registration_name .= $last_registration_info->user_nicename;
    	}
    	$last_registration_date = $last_registration_info->user_registered;
    	
    	$last_registration[] = array(
			'id' => $last_registration_id,
			'name' => $last_registration_name,
			'email' => $last_registration_info->user_email,
			'affiliate_id' => $last_registration_aff_id,
			'affiliate_name' => $last_registration_aff_name,
			'date' => $last_registration_date,
		);
	    $sql = "SELECT DISTINCT(meta_value) FROM $wpdb->usermeta WHERE meta_key='referral_id' AND meta_value!='0' AND meta_value!=''";
	    $referral_list = $wpdb->get_results($sql);
	    foreach ($referral_list as $referral) {
	    	$affiliate_info = get_userdata($referral->meta_value);
	    	$total_referred = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->usermeta WHERE meta_key='referral_id' AND meta_value='$affiliate_info->ID'" );
	    	$name = '';
	    	if (isset($affiliate_info->first_name) && $affiliate_info->first_name != '') {
		    	$name .= $affiliate_info->first_name;
	    	}
	    	if (isset($affiliate_info->last_name) && $affiliate_info->last_name != '') {
		    	$name .= ' '.$affiliate_info->last_name;
	    	}
	    	if ((!isset($affiliate_info->first_name) || $affiliate_info->first_name == '') && (!isset($affiliate_info->last_name) || $affiliate_info->last_name == '')) {
		    	$name .= $affiliate_info->user_nicename;
	    	}
	    	$affiliate_list[] = array(
				'id' => $affiliate_info->ID,
				'name' => ucwords(strtolower($name)),
				'email' => strtolower($affiliate_info->user_email),
				'total_referred' => $total_referred,
			);
		}
		
		foreach( $affiliate_list as $key => $row )
		{
		      $column1[$key] = $row[0];
		      $column2[$key] = $row[1];
		      $column3[$key] = $row[2];
		      $column4[$key] = $row[3];
		}	
		array_multisort($column4, SORT_DESC, $affiliate_list);
/* 		/print_r($affiliate_list);	 */
		
		array_slice($affiliate_list, 0, 10);
		
		$result[] = array(
			'access' => 'yes',
			'total_users' => $total_users['total_users'],
			'total_referrals' => $total_referrals,
			'total_affiliates' => $total_affiliates,
			'affiliates' => $affiliate_list,
			'last_registration' => $last_registration,
		);
	}
	echo json_encode($result);
} else {
	$result[] = array('access' => 'no');
	echo json_encode($result);

}
/*
if (isset($_GET["userid"]) && $_GET["userid"] != "" && $_GET["userid"] != "0") {
	function userTotalMobile() {
		global $wpdb;
		$userid = $_GET["userid"];
		$commisionAll_count = $wpdb->get_var( "SELECT COUNT(*) FROM `tranzactii` WHERE `user`='".$userid."' ");
		$commision0_count = $wpdb->get_var( "SELECT COUNT(*) FROM `tranzactii` WHERE `user`='".$userid."' AND `nivel`='level0'");
		$commision1_count = $wpdb->get_var( "SELECT COUNT(*) FROM `tranzactii` WHERE `user`='".$userid."' AND `nivel`='level1'");
		$commision2_count = $wpdb->get_var( "SELECT COUNT(*) FROM `tranzactii` WHERE `user`='".$userid."' AND `nivel`='level2'");
		$commisionAll_sum = round($wpdb->get_var( "SELECT SUM(`comision`) FROM `tranzactii` WHERE `user`='".$userid."'"),2);
		$commision0_sum = round($wpdb->get_var( "SELECT SUM(`comision`) FROM `tranzactii` WHERE `user`='".$userid."' AND `nivel`='level0'"),2);
		$commision1_sum = round($wpdb->get_var( "SELECT SUM(`comision`) FROM `tranzactii` WHERE `user`='".$userid."' AND `nivel`='level1'"),2);
		$commision2_sum = round($wpdb->get_var( "SELECT SUM(`comision`) FROM `tranzactii` WHERE `user`='".$userid."' AND `nivel`='level2'"),2);
		$reteanivel1 = round($wpdb->get_var( "SELECT COUNT(*) FROM wPp_usermeta WHERE `meta_key`='referral_id' AND `meta_value`='".$userid."'"),2);
		$prieteninivel1 = $wpdb->get_results( "SELECT user_id FROM wPp_usermeta WHERE `meta_key`='referral_id' AND `meta_value`='".$userid."'");
		$reteanivel2 = 0;
		foreach ($prieteninivel1 as $prieten) {
			$reteanivel2 += round($wpdb->get_var( "SELECT COUNT(*) FROM wPp_usermeta WHERE `meta_key`='referral_id' AND `meta_value`='".$prieten->user_id."'"),2);
		}
		
		
		return array($commisionAll_count, $commision0_count, $commision1_count, $commision2_count, $commisionAll_sum, $commision0_sum, $commision1_sum, $commision2_sum, $reteanivel1, $reteanivel2);	
	
	}
	$totaluri = userTotalMobile();
	$arr = array('totalnr' => $totaluri[0], 'totalnr0' => $totaluri[1], 'totalnr1' => $totaluri[2], 'totalnr2' => $totaluri[3], 'totalval' => $totaluri[4], 'totalval0' => $totaluri[5], 'totalval1' => $totaluri[6], 'totalval2' => $totaluri[7], 'reteanivel1' => $totaluri[8], 'reteanivel2' => $totaluri[9]);
	echo json_encode($arr);
} elseif (isset($_GET["parteneri"]) && $_GET["parteneri"] != "" && $_GET["parteneri"] == "true") {
	$blogusers = get_users('role=partener&orderby=login');
	foreach ($blogusers as $user) {
		$partenerAllMeta = get_user_meta($user->ID);
		$partenerid = $user->ID;
		$cash0 = get_user_meta($user->ID, 'cashback_level0', true);
		$cash1 = get_user_meta($user->ID, 'cashback_level1', true);
		$cash2 = get_user_meta($user->ID, 'cashback_level2', true);
		$partenername = $user->user_login;
		$partenertext = $partenerAllMeta['description'][0];
		$partenerimg = $partenerAllMeta['userphoto_image_file'][0];
		$partener[] = array(
			'id' => $partenerid,
			'nume' => $partenername,
			'text' => $partenertext,
			'cash0' => $cash0,
			'cash1' => $cash1,
			'cash2' => $cash2,
			'imagine' => $partenerimg,
		);
	}
	echo json_encode($partener);
}
*/

?>

<?php
require_once( '../../../wp-load.php' );


$user = $_GET['id'];
$user_info = get_userdata($user);
$downline = get_users(array('orderby' => 'registered', 'order' => 'DESC', 'meta_key' => 'referral_id','meta_value'=>$user));

$html_div_details .= '<table style="width: 100%; font-size: 13px; font-family: Arial;"><thead><tr><th align="center">No.</th><th align="left">Name</th><th align="left">Email</th><th align="left">Registration Date</th><th style="display: none;">Transaction</th></tr></thead><tbody>';
$i = count($downline);
foreach ($downline as $user) {
	$html_div_details.= '<tr><td align="center">'.$i.'.</td><td align="left">'.ucfirst(strtolower($user->first_name)).' '.ucfirst(strtolower($user->last_name)).'</td><td align="left">'.strtolower($user->user_email).'</td><td align="left">'.date("M j, Y", strtotime($user->user_registered)).'</td><td style="display: none;"></td></tr>';
	$i--;
}
$html_div_details .= '</tbody></table>';
echo $html_div_details;
?>
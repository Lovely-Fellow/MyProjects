jQuery(document).ready(function() {
    //jQuery('#myTable').tablesorter();
    jQuery('#theTable').DataTable();
});
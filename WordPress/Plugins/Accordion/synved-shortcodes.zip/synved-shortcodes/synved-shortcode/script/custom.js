// Copyright (c) 2011 Synved Ltd.
// All rights reserved
jQuery.noConflict();

jQuery(document).ready(function() 
{	
	synved_shortcode_apply_all();
});


=== PPM Accordion ===
Contributors: perfectpointmarketing
Donate link: 
Tags: jQuery Accordion, Accordion
Requires at least: 3.3
Tested up to: 3.5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will add an expand collapse accordion feature inside a post or page.


== Description ==

### PPM Accordion by http://perfectpointmarketing.com

This plugin will add an expand collapse accordion feature inside a post or page.

Plugin Features

* Shortcode System
* TinyMCE Button added for generating Shortcode.
* Very Lightweight. Only 12KB.
* Easy documentation
& many More.

Live Preview: http://perfectpointmarketing.com/plugins/ppm-accordion

== Installation ==

1. Install as a regular WordPress plugin
2. You have to use shortcode for generate accordion in post or page. Example shortcode is given below.
`[ppmaccordion][ppmtoggle title="Title"]...[/ppmtoggle] [ppmtoggle title="Title"]...[/ppmtoggle] [ppmtoggle title="Title"]...[/ppmtoggle][/ppmaccordion]` 



== Frequently asked questions ==


== Screenshots ==
1. PPM accordion in a post.


== Changelog ==

= 1.0 =
* Initial release


== Upgrade notice ==

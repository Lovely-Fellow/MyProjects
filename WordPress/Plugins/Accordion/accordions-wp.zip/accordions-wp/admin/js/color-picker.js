jQuery(document).ready(function(jQuery){
    jQuery('#sortable').sortable();
    jQuery('#custom-accordion-columns-bg-color, #custom-accordion-title-font-color,  #custom-accordion-content-bg-color, #custom-accordion-content-font-color').wpColorPicker();        
});
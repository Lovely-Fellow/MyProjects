<?php

require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'treebase.php' );

class NextendTreebaseWordpress extends NextendTreebase {

    function initConfig() {
        parent::initConfig();
    }

}